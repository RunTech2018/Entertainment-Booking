<?php
    require_once 'ModelPdo.php';

class ModelConcert extends ModelPdo {
  
   public static function getMusee($musee) {
        try {
           $sql= "select type_musee from musee where type_musee='$musee'";
			     $result=ModelPdo::$pdo->query($sql);
			     $unUser=$result->fetch();
			     return $unUser;
        } 
        catch (PDOException $e) {
            echo $e->getMessage();
            die("Erreur dans la BDD ");
        }
    }

       public static function getListeConcert($concert, $tagconcert) {
        try {
           $sql= "select * from concert where type_spectacle LIKE '%$concert%' AND style LIKE '%$tagconcert%'";
                 $result=ModelPdo::$pdo->query($sql);
                 $unUser=$result->fetchAll();
                 return $unUser;
        } 
        catch (PDOException $e) {
            echo $e->getMessage();
            die("Erreur dans la BDD ");
        }
    }

    public static function getListeConcertPrix($prix) {
        try {
           $sql= "select DISTINCT nom, auteur, date_concert, description, adresse, prix  from concert where prix < $prix";
                 $result=ModelPdo::$pdo->query($sql);
                 $unUser=$result->fetchAll();
                 return $unUser;
        } 
        catch (PDOException $e) {
            echo $e->getMessage();
            die("Erreur dans la BDD ");
        }
    }
}
?>