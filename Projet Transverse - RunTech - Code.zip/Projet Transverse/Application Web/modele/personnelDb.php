<?php
	// Update profile
    public function update($email,$gender,$location) {
        try {
        $stmt = $this->_db->prepare('UPDATE members SET email = ?, gender = ?, location = ? WHERE memberID = ? ');
        $stmt->execute(array($email,$gender,$location,$_SESSION['memberID']));
        return $stmt->fetch();
        } catch(PDOException $e) {
            echo '<p class="bg-danger">'.$e->getMessage().'</p>';
        }
    }// Update profile
    public function update($email,$gender,$location) {
        try {
        $stmt = $this->_db->prepare('UPDATE members SET email = ?, gender = ?, location = ? WHERE memberID = ? ');
        $stmt->execute(array($email,$gender,$location,$_SESSION['memberID']));
        return $stmt->fetch();
        } catch(PDOException $e) {
            echo '<p class="bg-danger">'.$e->getMessage().'</p>';
        }
    }
?>