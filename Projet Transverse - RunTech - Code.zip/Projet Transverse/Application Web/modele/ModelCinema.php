<?php
    require_once 'ModelPdo.php';

class ModelCinema extends ModelPdo {
  
   public static function getGenreCinema() {
        try {
           $sql= "select * from cinema";
			     $result=ModelPdo::$pdo->query($sql);
			     $unUser=$result->fetch();
			     return $unUser;
        } 
        catch (PDOException $e) {
            echo $e->getMessage();
            die("Erreur dans la BDD ");
        }
    }

       public static function getListeCinema($genrefilm, $tagfilm) {
        try {
           $sql= "select * from cinema where type_film LIKE '%$genrefilm%' AND categoriefilm LIKE '%$tagfilm%' ";
                 $result=ModelPdo::$pdo->query($sql);
                 $unUser=$result->fetchAll();
                 return $unUser;
        } 
        catch (PDOException $e) {
            echo $e->getMessage();
            die("Erreur dans la BDD ");
        }
    }

    //Insertion dans la Table Incident:
       public static function getidVehicule($id) {
        try {
           $sql= "select id from vehicule where id_responsable=$id ";
                 $result=ModelPdo::$pdo->query($sql);
                 $unVehicule=$result->fetch();
                 return $unVehicule[0];
        } 
        catch (PDOException $e) {
            echo $e->getMessage();
            die("Erreur dans la BDD ");
        }
    }

    public static function InsertIncident($idVehicule, $incident) {
        try {
           $sql= "INSERT INTO incident(idVehicule, description) Values($idVehicule, '$incident')";
           echo $sql;
            $result=ModelPdo::$pdo->exec($sql);
        } 
       catch(PDOException $e) {
            echo $e->getMessage();
            die("Erreur dans la BDD ");
        }
    }


    ////////////////////////////////////////////////////////////

    public static function getKmVehicule($idp)
    {
         try {
           $sql= "select km from vehicule where id=$idp ";
                 $result=ModelPdo::$pdo->query($sql);
                 $unKm=$result->fetch();
                 return $unKm[0];
        } 
        catch (PDOException $e) {
            echo $e->getMessage();
            die("Erreur dans la BDD ");
        }
    }
    
    public static function getVehiculeEntretien() {
        try {
           $sql= "select * from rdventretien";
                 $result=ModelPdo::$pdo->query($sql);
                 $unUser=$result->fetchAll();
                 return $unUser;
        } 
        catch (PDOException $e) {
            echo $e->getMessage();
            die("Erreur dans la BDD ");
        }
    }
        public static function getVehiculeGarage($idp) {
       try {
           $sql= "select * from vehicule where id=$idp ";
                 $result=ModelPdo::$pdo->query($sql);
                 $unUser=$result->fetch();
                 return $unUser;
        } 
        catch (PDOException $e) {
            echo $e->getMessage();
            die("Erreur dans la BDD ");
        }
    }
}
?>