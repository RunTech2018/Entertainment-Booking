<?php
    require_once 'ModelPdo.php';

class ModelSport extends ModelPdo {
  
   public static function getGenreSport() {
        try {
           $sql= "select * from sport";
			     $result=ModelPdo::$pdo->query($sql);
			     $unUser=$result->fetch();
			     return $unUser;
        } 
        catch (PDOException $e) {
            echo $e->getMessage();
            die("Erreur dans la BDD ");
        }
    }

       public static function getListeSport($sport) {
        try {
           $sql= "select * from sport where libelle_sport LIKE '%$sport%' OR type_sport LIKE '%$sport%'";
                 $result=ModelPdo::$pdo->query($sql);
                 $unUser=$result->fetchAll();
                 return $unUser;
        } 
        catch (PDOException $e) {
            echo $e->getMessage();
            die("Erreur dans la BDD ");
        }
    }

}
?>