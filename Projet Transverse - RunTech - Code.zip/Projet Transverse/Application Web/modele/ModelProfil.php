<?php

require_once 'ModelPdo.php';

class ModelProfil extends ModelPdo {
  
  public static function addUser($name, $prenom, $email, $login, $encrypted_txt) {
        try {
           $sql="INSERT INTO client(nom, prenom, email, login, password) values ('$name', '$prenom', '$email', '$login', '$encrypted_txt') ";
      $result=ModelPdo::$pdo->query($sql);
      $unUser=$result->fetch();
      return $unUser;
        } 
        catch (PDOException $e) {
            echo $e->getMessage();
            die("Erreur dans la BDD ");
        }
    }
    
   public static function getProfil($id) {
        try {
           $sql= "select * from client where id_client=$id ";
			     $result=ModelPdo::$pdo->query($sql);
			     $unUser=$result->fetch();
			     return $unUser;
        } 
        catch (PDOException $e) {
            echo $e->getMessage();
            die("Erreur dans la BDD ");
        }
    }
    //Récupérer mot de passe
    public static function getMdp($to) {
        try {
           $sql= "select mdp from client where mail='$to' ";
                 $result=ModelPdo::$pdo->query($sql);
                 $unUser=$result->fetch();
                 return $unUser;
        } 
        catch (PDOException $e) {
            echo $e->getMessage();
            die("Erreur dans la BDD ");
        }
    }
    // Update profile
    public static function Update($id, $nom,$prenom,$login, $mobile, $email) {
        try {
        $sql = "UPDATE client SET nom='$nom', prenom='$prenom', login='$login', telephone=$mobile, mail ='$email' WHERE id_client=$id ";
        $result=ModelPdo::$pdo->exec($sql);
        } catch(PDOException $e) {
            echo '<p class="bg-danger">'.$e->getMessage().'</p>';
        }
    }
    //Update Password
    public static function UpdatePassword($id, $plain_txt) {
        try {
        $sql = "UPDATE client SET password='$plain_txt' WHERE id_client=$id ";
        $result=ModelPdo::$pdo->exec($sql);
        } catch(PDOException $e) {
            echo '<p class="bg-danger">'.$e->getMessage().'</p>';
        }
    }
}
?>