<?php
    require_once 'ModelPdo.php';

class ModelParc extends ModelPdo {
  
   public static function getMusee($musee) {
        try {
           $sql= "select type_musee from musee where type_musee='$musee'";
			     $result=ModelPdo::$pdo->query($sql);
			     $unUser=$result->fetch();
			     return $unUser;
        } 
        catch (PDOException $e) {
            echo $e->getMessage();
            die("Erreur dans la BDD ");
        }
    }

       public static function getListeParc($parc) {
        try {
           $sql= "select * from parc where categorie LIKE '%$parc%' OR description LIKE '%$parc%'";
                 $result=ModelPdo::$pdo->query($sql);
                 $unUser=$result->fetchAll();
                 return $unUser;
        } 
        catch (PDOException $e) {
            echo $e->getMessage();
            die("Erreur dans la BDD ");
        }
    }

    public static function getListeParcPrix($parc) {
        try {
           $sql= "select DISTINCT nom, adresse, description, prix  from parc where prix < $parc";
                 $result=ModelPdo::$pdo->query($sql);
                 $unUser=$result->fetchAll();
                 return $unUser;
        } 
        catch (PDOException $e) {
            echo $e->getMessage();
            die("Erreur dans la BDD ");
        }
    }

}
?>