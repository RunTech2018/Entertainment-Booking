<?php

require_once 'ModelPdo.php';

class ModelConnexion extends ModelPdo {
  
   public static function getUser($login, $encrypted_txt) {
        try {
           $sql="select * from client where login='$login' and password='$encrypted_txt' ";
			$result=ModelPdo::$pdo->query($sql);
			$unUser=$result->fetch();
			return $unUser;
        } 
        catch (PDOException $e) {
            echo $e->getMessage();
            die("Erreur dans la BDD ");
        }
    }
    

    //public static function getUserGarage($login, $mdp) {
      //  try {
        //   $sql="select * from personnels inner join service on personnels.id_service = service.id where service.libellé='Garage' And personnels.login ='$login' and personnels.mdp='$mdp' ";
      //$result=ModelPdo::$pdo->query($sql);
      //$unUser=$result->fetch();
      //return $unUser;
        //} 
        //catch (PDOException $e) {
          //  echo $e->getMessage();
        //    die("Erreur dans la BDD ");
      //  }
    //}
}
?>