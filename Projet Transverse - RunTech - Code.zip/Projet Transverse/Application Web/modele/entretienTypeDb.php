<?php
//include("ConnectPdo.php");
class EntretienType{
	private $id;
	private $libelle;
	private $nbKm;
	private $nbKmTolere;
	
	public function __construct($id,$libelle,$nbk,$nbkt)
	{
		$this->id= $id;
		$this ->libelle = libelle;
		$this -> nbKm  = $nbk;
		$this -> nbKmTolere = $nbkt;
	}
	public function getIdEntretienType(){
		return $this-> id;
		
	}
	
	static function getAllEntretienType ($objPdo)
	{
		$sql="select * from entretienType";
		$result=$objPdo-> query($sql);
		$lignes=$result->fetchAll();
		return $lignes;
	}
	static function newEntretienType($libelle,$nbk,$nbkt,$objPdo)
	{
		try{
			$sql = "INSERT INTO entretienType VALUES (NULL,'$libelle', $nbk,$nbkt)";
			$res = $objPdo ->exec($sql);
		 
		
		}
		catch(PDOException $e)
		{
			die("erreur:".$e->getMessage());
		}
	}

}
?>