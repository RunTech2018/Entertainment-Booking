<?php
    require_once 'ModelPdo.php';

class ModelMusee extends ModelPdo {
  
   public static function getMusee($musee) {
        try {
           $sql= "select type_musee from musee where type_musee='$musee'";
			     $result=ModelPdo::$pdo->query($sql);
			     $unUser=$result->fetch();
			     return $unUser;
        } 
        catch (PDOException $e) {
            echo $e->getMessage();
            die("Erreur dans la BDD ");
        }
    }

    public static function getListeMusee2($musee) {
        try {
           $sql= "select * from musee where type_musee = '$musee'";
                 $result=ModelPdo::$pdo->query($sql);
                 $unUser=$result->fetchAll();
                 return $unUser;
        } 
        catch (PDOException $e) {
            echo $e->getMessage();
            die("Erreur dans la BDD ");
        }
    }

       public static function getListeMusee($musee) {
        try {
           $sql= "select DISTINCT nom, adresse, description, prix  from musee where type_musee LIKE '%$musee%' OR description LIKE '%$musee%'";
                 $result=ModelPdo::$pdo->query($sql);
                 $unUser=$result->fetchAll();
                 return $unUser;
        } 
        catch (PDOException $e) {
            echo $e->getMessage();
            die("Erreur dans la BDD ");
        }
    }

    public static function getListeMuseePrix($musee) {
        try {
           $sql= "select DISTINCT nom, adresse, description, prix from musee where prix < $musee";
                 $result=ModelPdo::$pdo->query($sql);
                 $unUser=$result->fetchAll();
                 return $unUser;
        } 
        catch (PDOException $e) {
            echo $e->getMessage();
            die("Erreur dans la BDD ");
        }
    }

}
?>