<?php
session_start();
//include("modele/connectDb.php");
include("vues/entete.php") ;
include("vues/sommaire.php");
include("metier/function.php");
//if (!isset($_SESSION['username'])) {
//	 $_REQUEST['action']="seconnecter";
//	 include("controleur/ctlconnection.php")
//}
//else{

	if(isset($_REQUEST['ctl']))
	{
		$ctl = $_REQUEST['ctl'];
			switch($ctl)
			{
				case 'connection' :
				{
					include("controleur/ctlconnection.php");break;
				}

				case 'email' :
				{
					include("controleur/ctlconnection.php");break;
				}

				case 'inscription' :
				{
					include("controleur/ctlconnection.php");break;
				}
							
				case 'profil':
				{
					include("controleur/ctlprofil.php");break;
				}
				
				case 'cinema':
				{
					include("controleur/ctlCinema.php");break;
				}
				case 'sport':
				{
					include("controleur/ctlSport.php");break;
				}
				case 'musee':
				{
					include("controleur/ctlMusee.php");break;
				}
				case 'entretien':
				{
					include("controleur/ctlEntretien.php");break;
				}
				case 'concert':
				{
					include("controleur/ctlConcert.php"); break;
				}

				case 'parc':
				{
					include("controleur/ctlParc.php");break;
				}
		    }
	}
include("vues/pied.php") ;
?>