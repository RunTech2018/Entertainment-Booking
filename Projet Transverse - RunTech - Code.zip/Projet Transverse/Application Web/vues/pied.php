</body>
<footer>
	<div class="col-md-4"></div>
	<div class="col-md-8">
		<p class="credits">Développé par <a href="http://digitalart.alwaysdata.net" target="_blank">Anil DEVADAS</a>.</p>
	</div>
</footer>
</html>