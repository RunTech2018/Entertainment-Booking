<div id="contenu">
<?php
		echo "Deconnexion en cours... Veuillez patienter";
?>
</div>