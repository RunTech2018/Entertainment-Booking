<!DOCTYPE html>
<html lang="fr">
    
    <head>
    
        <meta charset="utf-8">
        <title>Gestion d'un Parc de Véhicule</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="Connexion à mon application">
        <link rel="stylesheet" type="text/css" href="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" />
        <link rel="stylesheet" type="text/css" href="email.css" />
        <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Open+Sans:400,300" />
        <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Lato:400,700,300" />
        <script type="text/javascript" src="//code.jquery.com/jquery-1.11.0.min.js"></script>
        <script type="text/javascript" src="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
    </head>
    <body>
       <!-- START Nielsen//NetRatings SiteCensus V5.1 --> 

<!-- COPYRIGHT 2005 Nielsen//NetRatings --> 
<script language="JavaScript" type="text/javascript"> 

<!-- 

var _rsCI=""; 
var _rsCG="0"; 
var _rsDT=0; // to turn on whether to get the document title, 1=on 
var _rsDU=0; // to turn on or off the applet, 1=on 
var _rsDO=0; // to turn on debug output to the console, 1=on, only works if _rsDU=1 
var _rsX6=0; // to force use of applet with XP and IE6, 1=on, only works if _rsDU=1 

var _rsSI=escape(window.location); 



var _rsLP=location.protocol.indexOf('https')>-1?'https:':'http:'; 
var _rsRP=escape(document.referrer); 
var _rsND=_rsLP+'//secure-dk.imrworldwide.com/'; 

if (parseInt(navigator.appVersion)>=4) 
{ 
var _rsRD=(new Date()).getTime(); 
var _rsSE=0; // to turn on surveys, 1=on 
var _rsSV=""; // survey name, leave empty 
var _rsSM=0; // maximum survey rate, 1.0=100% 
_rsCL='<scr'+'ipt language="JavaScript" type="text/javascript" src="'+_rsND+'v51.js"><\/scr'+'ipt>'; 
} 
else 
{ 
_rsCL='<img src="'+_rsND+'cgi-bin/m?ci='+_rsCI+'&cg='+_rsCG+'&si='+_rsSI+'&rp='+_rsRP+'">'; 
} 
document.write(_rsCL); 

//--> 

</script> 

<noscript> 
<img src="http://secure-dk.imrworldwide.com/cgi-bin/m?ci=Habbohotel&cg=0" alt=""> 
</noscript> 



<!-- THE END Nielsen//NetRatings SiteCensus V5.1 --> 


<script src="urchin.js" type="text/javascript"> 
</script> 
<script type="text/javascript"> 
_uacct = "UA-448325-2"; 
urchinTracker(); 
</script> 

<!-- Start Quantcast tag --> 
<script language="JavaScript"> 
if (location.protocol == "http:") 
{ 
document.write('<scr'+'ipt language="JavaScript" type="text/javascript" src="http://edge.quantserve.com/quant.js"></scr'+'ipt>'); 
document.write('<scr'+'ipt language="JavaScript" type="text/javascript">_qacct="p-b5UDx6EsiRfMI";quantserve();</scr'+'ipt>'); 
} 
</script> 
<!-- End Quantcast tag --> 

<SCRIPT type=text/javascript> 
<!-- 
var omitformtags=["input", "textarea", "select"] 
omitformtags=omitformtags.join("|") 
function disableselect(e){ 
if (omitformtags.indexOf(e.target.tagName.toLowerCase())==-1) 
return false 
} 
function reEnable(){ 
return true 
} 
if (typeof document.onselectstart!="undefined") 
document.onselectstart=new Function ("return false") 
else{ 
document.onmousedown=disableselect 
document.onmouseup=reEnable 
} 
--> 
</SCRIPT> 
<script type="text/javascript">
document.onkeydown = function(e) {
    if(e.keyCode == 123) {
     return false;
    }
    if(e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)){
     return false;
    }
    if(e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)){
     return false;
    }
    if(e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)){
     return false;
    }

    if(e.ctrlKey && e.shiftKey && e.keyCode == 'C'.charCodeAt(0)){
     return false;
    }      
 }
</script>
<SCRIPT language=JavaScript> 
<!-- 
function HighScor() { 
props=window.open('challenge/index.php', 'poppage', 'toolbars=0, scrollbars=0, location=0, statusbars=0, menubars=0, resizable=0, width=525, height=485'); 
} 
// --> 
</SCRIPT> 
<!-- Disable Right Click --> 
<SCRIPT language=JavaScript> 
<!-- 
var message=""; 
/////////////////////////////////// 
function clickIE() {if (document.all) {(message);return false;}} 
function clickNS(e) {if 
(document.layers||(document.getElementById&&!document.all)) { 
if (e.which==2||e.which==3) {(message);return false;}}} 
if (document.layers) 
{document.captureEvents(Event.MOUSEDOWN);document.onmousedown=clickNS;} 
else{document.onmouseup=clickNS;document.oncontextmenu=clickIE;} 
document.oncontextmenu=new Function("return false") 
// --> 
</SCRIPT> 
<!-- Popup --> 
<SCRIPT language=JavaScript> 
<!-- 
function popUp(URL) { 
day = new Date(); 
id = day.getTime(); 
eval("page" + id + " = window.open(URL, '" + id + "', 'toolbar=0,scrollbars=0,location=0,statusbar=0,menubar=0,resizable=0,width=150,height=250,left = 437,top = 259');"); 
} 
// --> 
</SCRIPT>

<script>
    ssu = new SpeechSynthesisUtterance()
    ssu.lang = "fr-FR"
    ssu.text = "Voici la page d'inscription ! Veuillez remplir le formulaire pour vous inscrire !"
    speechSynthesis.speak(ssu)
</script>
    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                <div class="main">
                    <div class="row">
                        <div class="col-xs-12 col-sm-6 col-sm-offset-1">
                            <h2>Inscrivez-vous en remplissant les champs suivants ! </h2>
                                    
                            <?php
                                if(isset($_SESSION['erreurConnexion']))
                                {
                            ?>
                            <div class="form-group">
                                <div class="col-md-8">
                                    <p><font color=red><?php echo $_SESSION['erreurConnexion']; ?></font></p>
                                </div>
                            </div>
                            <?php
                                }
                            ?>
                            <style type="text/css">
                                .image{
                                    position: absolute;
                                    top:50px;
                                    left:475px;
                                }
                            </style>
                            <!--<div class="image"><img src="mercedes.jpg" heigh=550 width=550></img></div>-->
                            <form action="index.php?ctl=profil&action=inscription" name="login" role="form" class="form-horizontal" method="post" accept-charset="utf-8">
                                        
                                <div class="form-group">
                                    <div class="col-md-8"><input name="username" placeholder="Saisir votre Idenfiant" class="form-control" type="text" id="Username"/></div>
                                </div>

                                <div class="form-group">
                                    <div class="col-md-8"><input name="name" placeholder="Saisir votre Nom" class="form-control" type="text" id="Name"/></div>
                                </div>

                                <div class="form-group">
                                    <div class="col-md-8"><input name="prenom" placeholder="Saisir votre Prénom" class="form-control" type="text" id="Prenom"/></div>
                                </div>

                                <div class="form-group">
                                    <div class="col-md-8"><input name="email" placeholder="Saisir votre adresse Email" class="form-control" type="text" id="UserEmail"/></div>
                                </div>
                    
                                <div class="form-group">
                                    <div class="col-md-8"><input name="password" placeholder="Saisir votre Mot de passe" class="form-control" type="password" id="UserPassword"/></div>
                                </div>

                                <div class="form-group">
                                    <div class="col-md-offset-0 col-md-8"><input id="btnConnexion" class="btn btn-success btn btn-success" type="submit" value="Inscription"/></div>
                                </div>
                                <p class="credits"><a href="../../index.php?ctl=profil&action=seconnecter" target="_blank">Retour à la page de connexion</a></p>
                            </form>
                            <!--<p class="credits"><a href="index.php?ctl=connection&action=mdpOublier" target="_blank">Mot de passe oublié ?</a></p>-->
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>