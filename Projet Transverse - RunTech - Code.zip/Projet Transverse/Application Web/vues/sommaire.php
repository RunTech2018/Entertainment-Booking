   <!-- Division pour le sommaire -->
<div id="navigation" class="col-md-12">
	<ul>
		<?php
			if(isset($_SESSION['username']))
			{	
				echo "<li><a href='index.php?ctl=connection&action=deconnexion'>Deconnexion</a></li>";
				echo "<li><a href='index.php?ctl=profil&action=infoProfil'>Mon Profil</a></li>";
				echo "<li><a href='index.php?ctl=cinema&action=infoCinema'>Cinema</a></li>";
				echo "<li><a href='index.php?ctl=concert&action=infoConcert'>Spectacle</a></li>";
				echo "<li><a href='index.php?ctl=musee&action=infoMusee'>Musee</a></li>";
				echo "<li><a href='index.php?ctl=sport&action=infoSport'>Sport</a></li>";
				echo "<li><a href='index.php?ctl=parc&action=infoParc'>Parc</a></li>";



				if ($_SESSION['service']== 9) {
				echo "<li><a href='index.php?ctl=vehicule&action=listeVehicule'>Liste des Véhicules</a></li>";
				echo "<li><a href='index.php?ctl=entretien&action=infoEntretien'>Rendez-vous Entretien</a></li>";
				}

			}
			else
			{
				echo "<li class='col-md-12'><a href='index.php?ctl=connection&action=seconnecter'>Connexion</a></li>";
			}
		?>
	</ul>				
</div><!-- #navigation -->
    