<div class="container">
	<div class="row">
		<div class="col-xs-12">
			<div class="main">
				<div class="row">
					<div class="col-xs-12 col-sm-6 col-sm-offset-1">
                        
						<h1>Gestion de flotte MSL</h1>
						<h2>Gestion du personnel, des services et des véhicules...</h2>
									
						<p id="bienvenue">Bienvenue <font color=red><?php echo $_SESSION['username']; ?></font></p>
						
					</div>
				</div>
			</div>
		</div>
	</div>
</div>