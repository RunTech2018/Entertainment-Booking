<?php
	if (isset($_POST['submit'])) {
// new data
$nom= $_POST['nom'];
$prenom = $_POST['prenom'];
$login = $_POST['login'];
$email = $_POST['email'];
$mobile = $_POST['mobile'];
$datenaissance = $_POST['date'];
$id = $_SESSION['id'];

// query
if ($user->update($nom,$prenom,$login,$email,$datenaissance)); {
    redirect('modifierprofil.php');
}
}
?>