<div class="container">
		<div class="row">
			<div class="col-xs-12">
				<div class="main">
					<div class="row">
						<div class="col-xs-12 col-sm-6 col-sm-offset-1">
	<h1>Changer Votre Mot de Passe</h1>
	<div class="form-group">

							<form action="index.php?ctl=profil&action=changePassword" name="modifier" role="form" class="form-horizontal" method="post" accept-charset="utf-8">
								<!--<p>Votre Mot de Passe crypté actuel est:</p>	
								<div class="form-group">
									<div class="col-md-8"><input name="mpd" placeholder="" class="form-control" type="text" id="UserUsername" value = "<?php  echo $profil['password']; ?>"/></div>
								</div>-->
								<p>Modifiez votre Mot de passe ici:</p>	
								<div class="form-group">
									<div class="col-md-8"><input name="mdp" placeholder="Modifier le Mot de Passe" class="form-control" type="text" id="Nom"/>
									</div>
								</div>
								<!--<div class="form-group">
									<div class="col-md-8"><input name="confirm" placeholder="Confirmer le Mot de Passe" class="form-control" type="text" id="Nom"/>
									</div>-->
								</div>
							<div class="form-group">
									<div class="col-md-offset-0 col-md-8"><input id="btn" name="submit" class="btn btn-success btn btn-success" type="submit" 
										value="Modifier votre Mot de Passe"/></div>
								</div>