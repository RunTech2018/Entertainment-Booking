<?php

?>
	<div class="container">
		<div class="row">
			<div class="col-xs-12">
				<div class="main">
					<div class="row">
						<div class="col-xs-12 col-sm-6 col-sm-offset-1">
	<h1>Quel spectacle souhaitez vous voir ? </h1>
	<h2>Faites votre recherche en remplissant le champ présent en fonction de votre recherche</h2>
<style type="text/css">
	.contenu .colonne{
		color: grey;
	}
</style>
<script>
	ssu = new SpeechSynthesisUtterance()
	ssu.lang = "fr-FR"
	ssu.text = "Vous êtes sur la page Recherche de Spectacle! Vous avez deux type de recherche. La première est de remplir les champ en fonction du genre et du thème de spectacle que vous souhaitez voir. La deuxième est de remplir le champ tout en bas en fonction d'un certains tarif en euros que vous ne souhaitez pas dépasser. Attention, pour rechercher en fonction du tarif, veuillez ne pas saisir un chiffre à virgule ! Aussi ces types de recherches sont totalement indépendant. Vous ne devez remplir que l'un des champs ci-dessous. Bonne recherche !"
	speechSynthesis.speak(ssu)
</script>
<div id="contenu">

<form action="index.php?ctl=concert&action=listeConcert" name="modifier" role="form" class="form-horizontal" method="post" accept-charset="utf-8">
										
<div class="form-group">

								<p> Quel type de spectacle souhaitez-vous voir ? (Danse, Comédie Musical, Concert...):</p>
								<div class="form-group">
									<div class="col-md-8"><input name="concert" placeholder="Saisir le genre de spectacle (Danse, Comédie Musical, Concert, Théâtre...)" class="form-control" type="text" id="Km" 
										value = ""/></div>
								</div><br>

								<p> Quel est le thème du spectacle que vous recherchez ? (Exemple: hip pop, rock, classique...) :</p>
								<div class="form-group">
									<div class="col-md-8"><input name="tagconcert" placeholder="Tag de spectacle (hip pop, rock, comique...)" class="form-control" type="text" id="Km" 
										value = ""/></div>
								</div><br>

								<div class="form-group">
									<div class="col-md-offset-0 col-md-8"><input id="btn" name="submit" class="btn btn-success btn btn-success" type="submit" 
										value="Lancer la recherche"/></div>
								</div>
</form>

<h2>Vous pouvez aussi faire votre recherche de spectacle en fonction d'un certain seuil de prix :</h2>
<form action="index.php?ctl=concert&action=prix" name="modifier" role="form" class="form-horizontal" method="post" accept-charset="utf-8">
<div class="form-group">
								<p>Donnez un seuil de prix de billet que vous ne souhaitez pas dépasser (pas de chiffre avec virgule)</p>
								<br>
								<div class="form-group">
									<div class="col-md-8"><input name="prix" placeholder="Remplissez le champ pour effectuer votre recherche" class="form-control" type="text" id="Musee" 
										value = ""/></div>
								</div><br>

								<div class="form-group">
									<div class="col-md-offset-0 col-md-8"><input id="btn" name="submit" class="btn btn-success btn btn-success" type="submit" 
										value="Lancer la recherche"/></div>
								</div>
</form>
