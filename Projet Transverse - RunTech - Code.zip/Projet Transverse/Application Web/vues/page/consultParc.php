<?php

?>
	<div class="container">
		<div class="row">
			<div class="col-xs-12">
				<div class="main">
					<div class="row">
						<div class="col-xs-12 col-sm-6 col-sm-offset-1">
	<h1>Dans quel type de Parc souhaitez-vous aller ? </h1>
	<h2>Faites votre recherche en remplissant le champ suivant</h2>
<style type="text/css">
	.contenu .colonne{
		color: grey;
	}
	
</style>
<script>
	ssu = new SpeechSynthesisUtterance()
	ssu.lang = "fr-FR"
	ssu.text = "Vous êtes sur la page Recherche de Parc ! Vous avez deux type de recherche. La première est de remplir le champ en fonction du type de parc où vous souhaitez aller en fonction de votre goût. Indiquez simplement une expression clé comme par exemple looping ou encore zoo. La deuxième est de remplir le champ tout en bas en fonction d'un certains tarif en euros que vous ne souhaitez pas dépasser. Attention, pour rechercher en fonction du tarif, veuillez ne pas saisir un chiffre à virgule ! Aussi ces types de recherches sont totalement indépendant. Vous ne devez remplir que l'un des champs ci-dessous. Bonne recherche !"
	speechSynthesis.speak(ssu)
</script>
<div id="contenu">

<form action="index.php?ctl=parc&action=correction" name="modifier" role="form" class="form-horizontal" method="post" accept-charset="utf-8">
<div class="form-group">
								<p>Donnez le type de parc où vous souhaitez aller (parc d'attraction, zoo...) ou encore donnez nous le type de parc en fonction de votre goût (sensation forte, looping, parc animalier, famille...):</p>
								<br>
								<div class="form-group">
									<div class="col-md-8"><input name="parc" placeholder="Remplissez le champ pour effectuer votre recherche" class="form-control" type="text" id="Musee" 
										value = ""/></div>
								</div><br>

								<div class="form-group">
									<div class="col-md-offset-0 col-md-8"><input id="btn" name="submit" class="btn btn-success btn btn-success" type="submit" 
										value="Lancer la recherche"/></div>
								</div>
</form>
<h2>Vous pouvez aussi faire votre recherche de spectacle en fonction d'un certain seuil de prix :</h2>
<form action="index.php?ctl=parc&action=prix" name="modifier" role="form" class="form-horizontal" method="post" accept-charset="utf-8">
<div class="form-group">
								<p>Donnez un seuil de prix de billet que vous ne souhaitez pas dépasser (pas de chiffre avec virgule)</p>
								<br>
								<div class="form-group">
									<div class="col-md-8"><input name="prix" placeholder="Remplissez le champ pour effectuer votre recherche" class="form-control" type="text" id="Musee" 
										value = ""/></div>
								</div><br>

								<div class="form-group">
									<div class="col-md-offset-0 col-md-8"><input id="btn" name="submit" class="btn btn-success btn btn-success" type="submit" 
										value="Lancer la recherche"/></div>
								</div>
</form>
