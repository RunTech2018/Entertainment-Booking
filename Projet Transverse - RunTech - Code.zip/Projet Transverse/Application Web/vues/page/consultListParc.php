<?php

?>
	<div class="container">
		<div class="row">
			<div class="col-xs-12">
				<div class="main">
					<div class="row">
						<div class="col-xs-12 col-sm-6 col-sm-offset-1">
	<h1>Liste des Musées proposés en fonction de votre recherche</h1><br><br>
	<!--<h2>Gérer votre véhicule</h2>-->
<style type="text/css">
	.contenu .colonne{
		color: grey;
		width: 250px;
	}
</style>
<div id="contenu">
<table border= "1" text-align="center">
	<tr>
		<div class="colonne">
		<td><center>Nom</center></td>
		<td><center>Adresse du Musée</center></td>
		<td><center>Description</center></td>
		<td><center>Prix du Billet en Euros</center></td>
		</div>
	  </tr>
	 <?php 
	 		foreach ($listparc as $unvehicule) {
	 			echo "<tr>";
	 			echo "<td><center>".$unvehicule['nom']."</center></td>";
	 			echo "<td><center>".$unvehicule['adresse']."</center></td>";
	 			echo "<td><center>".$unvehicule['description']."</center></td>";
	 			echo "<td><center>".$unvehicule['prix']."</center></td>";
	 			echo "</tr>";
	 		}
	 ?>
</table>
<script>
	ssu = new SpeechSynthesisUtterance()
	ssu.lang = "fr-FR"
	ssu.text = "Voici la liste des parc proposés en fonction de votre recherche par rapport au seuil de prix. Vous pouvez cliquer sur le bouton tout en bas pour vous diriger vers Google Map et localiser votre destination avec les listes des meilleurs trajets vous conduisant au lieu de votre choix."
	speechSynthesis.speak(ssu)
</script>
<div class="form-group">
								<p>Pour rechercher un endroit et connaitre les différents moyens pour y aller, cliquez sur le bouton suivante:</p>
								<br>
								<div class="form-group">
									<div class="col-md-offset-0 col-md-8"><a href="https://www.google.com/maps/dir/Paris" target="_blank"><input id="btn" name="submit" class="btn btn-success btn btn-success" type="submit" 
										value="Rechercher un lieu et son trajet !"/></a></div>
								</div>
