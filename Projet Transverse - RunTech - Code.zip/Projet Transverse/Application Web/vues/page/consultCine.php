<?php

?>
	<div class="container">
		<div class="row">
			<div class="col-xs-12">
				<div class="main">
					<div class="row">
						<div class="col-xs-12 col-sm-6 col-sm-offset-1">
	<h1>Quel film souhaitez vous voir ? </h1>
	<h2>Faites votre recherche en remplissant les champs présents en fonction de votre recherche</h2>
<style type="text/css">
	.contenu .colonne{
		color: grey;
	}
</style>
<!-- Voix de l'application-->
<script>
	ssu = new SpeechSynthesisUtterance()
	ssu.lang = "fr-FR" //Paramètre de la langue
	//Texte que la voix doit dire !
	ssu.text = "Voici la page de recherche de film ! Veuillez remplir les deux champs ci-dessous pour effectuer votre recherche. L'un correspond au genre de film que vous aimez voir comme le genre fantastique, la comédie, les films d'aventure ou d'action . Le deuxième champ correspond thème se rapportant au genre de film, comme par exemple l'espionnage, les loups garou, les vampires, les cascades de voitures ou encore les courses poursuites"
	speechSynthesis.speak(ssu)
</script>
<div id="contenu">

<form action="index.php?ctl=cinema&action=listeCinema" name="modifier" role="form" class="form-horizontal" method="post" accept-charset="utf-8">
										
<div class="form-group">
								<p>Quel Genre de film aimez-vous ? (Fantastique, Comédie, Horreur, Action, Aventure...):</p>
								<div class="form-group">
									<div class="col-md-8"><input name="genre" placeholder="Genre de Film" class="form-control" type="text" id="Km" 
										value = ""/></div>
								</div><br>

								<p>Quel thème se rapportant au genre de film aimez-vous ? (Espionnage, Vampire, Sorcellerie, Cascades de voitures...) ?:</p>
								<div class="form-group">
									<div class="col-md-8"><input name="tagfilm" placeholder="Tag de film (Vampire, Loups-garous, Cascades...)" class="form-control" type="text" id="Km" 
										value = ""/></div>
								</div><br>

								<div class="form-group">
									<div class="col-md-offset-0 col-md-8"><input id="btn" name="submit" class="btn btn-success btn btn-success" type="submit" 
										value="Lancer la recherche"/></div>
								</div>
</form>
