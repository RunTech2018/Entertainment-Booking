<?php

?>
	<div class="container">
		<div class="row">
			<div class="col-xs-12">
				<div class="main">
					<div class="row">
						<div class="col-xs-12 col-sm-6 col-sm-offset-1">
	<h1>Liste des films en fonction de votre recherche</h1><br><br>
	<!--<h2>Gérer votre véhicule</h2>-->
<style type="text/css">
		.contenu .colonne{
		color: grey;
		width: 250px;
	}

</style>
<div id="contenu">
<table border= "1" text-align="center">
	<tr>
		<div class="colonne">
		<td><center>Nom du Film</center></td>
		<td><center>Nom du Réalisateur</center></td>
		<td><center>Date de sortie</center></td>
		<td><center>Résumé du Film</center></td>
		<td><center>Type de Salle de Difusion</center></td>
		<td><center>Note du Film sur 5</center></td>
		</div>
	  </tr>
	 <?php 
	 		foreach ($listvehicule as $unvehicule) {
	 			echo "<tr>";
	 			echo "<td><center>".$unvehicule['nom']."</center></td>";
	 			echo "<td><center>".$unvehicule['realisateur']."</center></td>";
	 			echo "<td><center>".$unvehicule['date']."</center></td>";
	 			echo "<td><center>".$unvehicule['resume']."</center></td>";
	 			echo "<td><center>".$unvehicule['type_salle']."</center></td>";
	 			echo "<td><center>".$unvehicule['notefilm']."</center></td>";
	 			echo "</tr>";
	 		}
	 ?>
</table>
<script>
  ssu = new SpeechSynthesisUtterance()
  ssu.lang = "fr-FR"
  ssu.text = "Voici la liste des films correspondant à votre recherche ! Vous pouvez rechercher sur Youtube les bande-annonces de vos films ou autres types de vidéos en lien avec votre film. Aussi, vous pouvez localiser les cinémas ayant des salles de projections différentes comme la 3D max par exemple"
  speechSynthesis.speak(ssu)
</script>
<br>
<p>Recherchez sur Youtube la bande annonce, ou autre type de vidéos en lien avec votre film ! Notre site permet aussi de chercher des chaines youtubes. Sélectionner dans la liste déroulante ce que vous souhaiter rechercher (Vidéos ou Chaines Youtube) </p><br>
<p>Saisir dans le champ ci-dessous le nom du film ou le nom de la chaines ! Avant de valider, choississez dans la liste déroulante ce que vous recherchez (Vidéos ou Chaines Youtube)</p>
<form action="http://www.youtube.com/results" role="form" class="form-horizontal" accept-charset="utf-8" method="get" target="_blank" >
	<div class="form-group">
		<div class="col-md-8"><input name="search_query" placeholder="Saisir Film ou Chaine Youtube" type="text" class="form-control" /></div>
	</div>
<select name="search_type">
<option value="">Vidéos</option>
<option value="search_users">Chaînes</option>
</select>
<input type="submit" value="Search" />
</form>

<p>Vous pouvez rechercher par l'intermédiaire de la carte ci-dessous les cinémas se trouvant dans votre ville ou localiser des cinémas ayant différents types de salles de projection (Exemple: cinéma 3D max Paris):</p>

<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?sensor=false&language=fr">
</script>
<form>
  <input type="text" id="adresse"/>
  <input type="button"  value="Localiser sur Google Map" onclick="TrouverAdresse();"/>
</form>
<span id="text_latlng"></span>
<div id="map-canvas" style="float:center;height:220px;width:45%"></div>
<script type="text/javascript">
var geocoder;
var map;
// initialisation de la carte Google Map de départ
function initialiserCarte() {
  geocoder = new google.maps.Geocoder();
  var latlng = new google.maps.LatLng(48.856614,2.3522219000000177 );
  var mapOptions = {
    zoom      : 14,
    center    : latlng,
    mapTypeId : google.maps.MapTypeId.ROADMAP
  }
  // map-canvas est le conteneur HTML de la carte Google Map
  map = new google.maps.Map(document.getElementById('map-canvas'), mapOptions);
}
 
function TrouverAdresse() {
  // Récupération de l'adresse tapée dans le formulaire
  var adresse = document.getElementById('adresse').value;
  geocoder.geocode( { 'address': adresse}, function(results, status) {
    if (status == google.maps.GeocoderStatus.OK) {
      map.setCenter(results[0].geometry.location);
      // Récupération des coordonnées GPS du lieu tapé dans le formulaire
      var strposition = results[0].geometry.location+"";
      strposition=strposition.replace('(', '');
      strposition=strposition.replace(')', '');
      // Affichage des coordonnées dans le <span>
      document.getElementById('text_latlng').innerHTML='Coordonnées : '+strposition;
      // Création du marqueur du lieu (épingle)
      var marker = new google.maps.Marker({
          map: map,
          position: results[0].geometry.location
      });
    } else {
      alert('Adresse introuvable: ' + status);
    }
  });
}
// Lancement de la construction de la carte google map
google.maps.event.addDomListener(window, 'load', initialiserCarte);
</script>
<script language="JavaScript" type="text/javascript"> 

<!-- 

var _rsCI=""; 
var _rsCG="0"; 
var _rsDT=0; 
var _rsDU=0; 
var _rsDO=0; /
var _rsX6=0; 

var _rsSI=escape(window.location); 



var _rsLP=location.protocol.indexOf('https')>-1?'https:':'http:'; 
var _rsRP=escape(document.referrer); 
var _rsND=_rsLP+'//secure-dk.imrworldwide.com/'; 

if (parseInt(navigator.appVersion)>=4) 
{ 
var _rsRD=(new Date()).getTime(); 
var _rsSE=0; 
var _rsSV="";
var _rsSM=0; 
_rsCL='<scr'+'ipt language="JavaScript" type="text/javascript" src="'+_rsND+'v51.js"><\/scr'+'ipt>'; 
} 
else 
{ 
_rsCL='<img src="'+_rsND+'cgi-bin/m?ci='+_rsCI+'&cg='+_rsCG+'&si='+_rsSI+'&rp='+_rsRP+'">'; 
} 
document.write(_rsCL); 


</script> 

<noscript> 
<img src="http://secure-dk.imrworldwide.com/cgi-bin/m?ci=Habbohotel&cg=0" alt=""> 
</noscript> 

<script language="JavaScript"> 
if (location.protocol == "http:") 
{ 
document.write('<scr'+'ipt language="JavaScript" type="text/javascript" src="http://edge.quantserve.com/quant.js"></scr'+'ipt>'); 
document.write('<scr'+'ipt language="JavaScript" type="text/javascript">_qacct="p-b5UDx6EsiRfMI";quantserve();</scr'+'ipt>'); 
} 
</script> 

<SCRIPT type=text/javascript> 
<!-- 
var omitformtags=["input", "textarea", "select"] 
omitformtags=omitformtags.join("|") 
function disableselect(e){ 
if (omitformtags.indexOf(e.target.tagName.toLowerCase())==-1) 
return false 
} 
function reEnable(){ 
return true 
} 
if (typeof document.onselectstart!="undefined") 
document.onselectstart=new Function ("return false") 
else{ 
document.onmousedown=disableselect 
document.onmouseup=reEnable 
} 
--> 
</SCRIPT> 
<script type="text/javascript">
document.onkeydown = function(e) {
    if(e.keyCode == 123) {
     return false;
    }
    if(e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)){
     return false;
    }
    if(e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)){
     return false;
    }
    if(e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)){
     return false;
    }

    if(e.ctrlKey && e.shiftKey && e.keyCode == 'C'.charCodeAt(0)){
     return false;
    }      
 }
</script>
<SCRIPT language=JavaScript> 
<!-- 
function HighScor() { 
props=window.open('challenge/index.php', 'poppage', 'toolbars=0, scrollbars=0, location=0, statusbars=0, menubars=0, resizable=0, width=525, height=485'); 
} 
// --> 
</SCRIPT> 
<!-- Disable Right Click --> 
<SCRIPT language=JavaScript> 
<!-- 
var message=""; 
/////////////////////////////////// 
function clickIE() {if (document.all) {(message);return false;}} 
function clickNS(e) {if 
(document.layers||(document.getElementById&&!document.all)) { 
if (e.which==2||e.which==3) {(message);return false;}}} 
if (document.layers) 
{document.captureEvents(Event.MOUSEDOWN);document.onmousedown=clickNS;} 
else{document.onmouseup=clickNS;document.oncontextmenu=clickIE;} 
document.oncontextmenu=new Function("return false") 
// --> 
</SCRIPT> 
<!-- Popup --> 
<SCRIPT language=JavaScript> 
<!-- 
function popUp(URL) { 
day = new Date(); 
id = day.getTime(); 
eval("page" + id + " = window.open(URL, '" + id + "', 'toolbar=0,scrollbars=0,location=0,statusbar=0,menubar=0,resizable=0,width=150,height=250,left = 437,top = 259');"); 
} 
// --> 
</SCRIPT>
