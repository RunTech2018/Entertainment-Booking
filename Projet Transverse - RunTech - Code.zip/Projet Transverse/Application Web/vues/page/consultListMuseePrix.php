<?php

?>
	<div class="container">
		<div class="row">
			<div class="col-xs-12">
				<div class="main">
					<div class="row">
						<div class="col-xs-12 col-sm-6 col-sm-offset-1">
	<h1>Liste des Musées proposés en fonction de votre recherche</h1><br><br>
	<!--<h2>Gérer votre véhicule</h2>-->
<style type="text/css">
	.contenu .colonne{
		color: grey;
		width: 250px;
	}
</style>
<div id="contenu">
<table border= "1" text-align="center">
	<tr>
		<div class="colonne">
		<td><center>Nom</center></td>
		<td><center>Adresse du Musée</center></td>
		<td><center>Description</center></td>
		<td><center>Prix du Billet en Euros</center></td>
		</div>
	  </tr>
	 <?php 
	 		foreach ($listmusee as $unvehicule) {
	 			echo "<tr>";
	 			echo "<td><center>".$unvehicule['nom']."</center></td>";
	 			echo "<td><center>".$unvehicule['adresse']."</center></td>";
	 			echo "<td><center>".$unvehicule['description']."</center></td>";
	 			echo "<td><center>".$unvehicule['prix']."</center></td>";
	 			echo "</tr>";
	 		}
	 ?>
</table>
<script>
	ssu = new SpeechSynthesisUtterance()
	ssu.lang = "fr-FR"
	ssu.text = "Voici la liste des musées proposés en fonction de votre recherche. Vous pouvez ensuite rechercher par l'intermédiaire de la carte ci-dessous d'autres musée se trouvant dans une ville ou rechercher des musées proches de votre ville ! Le bouton rechercher un lieu et son trajet vous dirigera vers une autre carte de Google Map vous permettant de localiser un lieu, ainsi que la liste des différents types de trajets pour vous y rendre !"
	speechSynthesis.speak(ssu)
</script>
<br><br>
<p>Vous pouvez rechercher par l'intermédiaire de la carte ci-dessous d'autres musée se trouvant dans une ville ou rechercher des musées proches de votre ville (Exemple: Musée Paris):</p>

<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?sensor=false&language=fr">
</script>
<form>
  <input type="text" id="adresse"/>
  <input type="button"  value="Localiser sur Google Map" onclick="TrouverAdresse();"/>
</form>
<span id="text_latlng"></span>
<div id="map-canvas" style="float:center;height:220px;width:45%"></div>
<script type="text/javascript">
var geocoder;
var map;
// initialisation de la carte Google Map de départ
function initialiserCarte() {
  geocoder = new google.maps.Geocoder();
  var latlng = new google.maps.LatLng(48.856614,2.3522219000000177 );
  var mapOptions = {
    zoom      : 14,
    center    : latlng,
    mapTypeId : google.maps.MapTypeId.ROADMAP
  }
  // map-canvas est le conteneur HTML de la carte Google Map
  map = new google.maps.Map(document.getElementById('map-canvas'), mapOptions);
}
 
function TrouverAdresse() {
  // Récupération de l'adresse tapée dans le formulaire
  var adresse = document.getElementById('adresse').value;
  geocoder.geocode( { 'address': adresse}, function(results, status) {
    if (status == google.maps.GeocoderStatus.OK) {
      map.setCenter(results[0].geometry.location);
      // Récupération des coordonnées GPS du lieu tapé dans le formulaire
      var strposition = results[0].geometry.location+"";
      strposition=strposition.replace('(', '');
      strposition=strposition.replace(')', '');
      // Affichage des coordonnées dans le <span>
      document.getElementById('text_latlng').innerHTML='Coordonnées : '+strposition;
      // Création du marqueur du lieu (épingle)
      var marker = new google.maps.Marker({
          map: map,
          position: results[0].geometry.location
      });
    } else {
      alert('Adresse introuvable: ' + status);
    }
  });
}
// Lancement de la construction de la carte google map
google.maps.event.addDomListener(window, 'load', initialiserCarte);
</script>
<br>
<div class="form-group">
								<p>Pour connaitre les différents moyens pour aller un musée ou une autre destination, cliquez sur le bouton suivante:</p>
								<br>
								<div class="form-group">
									<div class="col-md-offset-0 col-md-8"><a href="https://www.google.com/maps/dir/Paris" target="_blank"><input id="btn" name="submit" class="btn btn-success btn btn-success" type="submit" 
										value="Rechercher un lieu et son trajet !"/></a></div>
								</div>