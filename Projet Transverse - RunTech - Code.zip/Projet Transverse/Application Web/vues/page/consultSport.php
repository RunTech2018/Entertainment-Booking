<?php

?>
	<div class="container">
		<div class="row">
			<div class="col-xs-12">
				<div class="main">
					<div class="row">
						<div class="col-xs-12 col-sm-6 col-sm-offset-1">
	<h1>Quel type de sport vous intéresse ? </h1>
	<h2>Faites votre recherche en remplissant le champ suivant</h2>
<style type="text/css">
	.contenu .colonne{
		color: grey;
	}

</style>
<script>
	ssu = new SpeechSynthesisUtterance()
	ssu.lang = "fr-FR"
	ssu.text = " Vous êtes sur la page de Recherche de sports. Cette page permet de vous trouver les sports correspondant à votre demande, ainsi que les clubs qui enseignent l'activité sportives. Pour effectuer votre recherche, veuillez remplir le champ ci-dessous en donnant soit le nom du sport, soit un indice de la catégorie dans lequel ce sport est rangé comme par exemple: raquettes, baskets, panier...."
	speechSynthesis.speak(ssu)
</script>
<div id="contenu">

<form action="index.php?ctl=sport&action=listeSport" name="modifier" role="form" class="form-horizontal" method="post" accept-charset="utf-8">
										
<div class="form-group">
								<p>Quel sport aimez-vous ? Donnez soit le nom du sport (badmitton, natation, équitation...) ou la catégorie de sport (aquatique, raquettes, sport d'équipe, sport du désert, sport de montagne...):</p>
								<br>
								<div class="form-group">
									<div class="col-md-8"><input name="sport" placeholder="Remplissez le champ pour effectuer votre recherche" class="form-control" type="text" id="Km" 
										value = ""/></div>
								</div><br>

								<div class="form-group">
									<div class="col-md-offset-0 col-md-8"><input id="btn" name="submit" class="btn btn-success btn btn-success" type="submit" 
										value="Lancer la recherche"/></div>
								</div>
</form>
