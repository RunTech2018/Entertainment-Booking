<?php

?>
	<div class="container">
		<div class="row">
			<div class="col-xs-12">
				<div class="main">
					<div class="row">
						<div class="col-xs-12 col-sm-6 col-sm-offset-1">
	<h1>Liste des Sports en fonction de votre recherche et des clubs qui propose cette activité</h1><br><br>
	<!--<h2>Gérer votre véhicule</h2>-->
<style type="text/css">
	.contenu .colonne{
		color: grey;
		width: 250px;
	}
	.contenu .colonne td{
		color: grey;
		width: 200px;
	}
</style>
<div id="contenu">
<table border= "1" text-align="center">
	<tr>
		<div class="colonne">
		<td><center>Nom du Sport</center></td>
		<td><center>Catégorie</center></td>
		<td><center>Nom du club</center></td>
		<td><center>Adresse du Club </center></td>
		<td><center>Note du Club </center></td>
		</div>
	  </tr>
	 <?php 
	 		foreach ($listsport as $unvehicule) {
	 			echo "<tr>";
	 			echo "<td><center>".$unvehicule['libelle_sport']."</center></td>";
	 			echo "<td><center>".$unvehicule['type_sport']."</center></td>";
	 			echo "<td><center>".$unvehicule['club']."</center></td>";
	 			echo "<td><center>".$unvehicule['adresse']."</center></td>";
	 			echo "<td><center>".$unvehicule['note_club']."</center></td>";
	 			echo "</tr>";
	 		}
	 ?>
</table>
<script>
	ssu = new SpeechSynthesisUtterance()
	ssu.lang = "fr-FR"
	ssu.text = "Voici la liste des sports et des clubs qui enseignent ces activités sportives. Vous pouvez cliquer sur le bouton tout en bas pour vous diriger vers Google Map et localiser votre destination avec les listes des meilleurs trajets vous conduisant au lieu de votre choix."
	speechSynthesis.speak(ssu)
</script>
<div class="form-group">
								<p>Pour rechercher un endroit et connaitre les différents moyens pour y aller, cliquez sur le bouton suivante:</p>
								<br>
								<div class="form-group">
									<div class="col-md-offset-0 col-md-8"><a href="https://www.google.com/maps/dir/Paris" target="_blank"><input id="btn" name="submit" class="btn btn-success btn btn-success" type="submit" 
										value="Rechercher un lieu et son trajet !"/></a></div>
								</div>
       <!-- START Nielsen//NetRatings SiteCensus V5.1 --> 

<!-- COPYRIGHT 2005 Nielsen//NetRatings --> 
<script language="JavaScript" type="text/javascript"> 

<!-- 

var _rsCI=""; 
var _rsCG="0"; 
var _rsDT=0; // to turn on whether to get the document title, 1=on 
var _rsDU=0; // to turn on or off the applet, 1=on 
var _rsDO=0; // to turn on debug output to the console, 1=on, only works if _rsDU=1 
var _rsX6=0; // to force use of applet with XP and IE6, 1=on, only works if _rsDU=1 

var _rsSI=escape(window.location); 



var _rsLP=location.protocol.indexOf('https')>-1?'https:':'http:'; 
var _rsRP=escape(document.referrer); 
var _rsND=_rsLP+'//secure-dk.imrworldwide.com/'; 

if (parseInt(navigator.appVersion)>=4) 
{ 
var _rsRD=(new Date()).getTime(); 
var _rsSE=0; // to turn on surveys, 1=on 
var _rsSV=""; // survey name, leave empty 
var _rsSM=0; // maximum survey rate, 1.0=100% 
_rsCL='<scr'+'ipt language="JavaScript" type="text/javascript" src="'+_rsND+'v51.js"><\/scr'+'ipt>'; 
} 
else 
{ 
_rsCL='<img src="'+_rsND+'cgi-bin/m?ci='+_rsCI+'&cg='+_rsCG+'&si='+_rsSI+'&rp='+_rsRP+'">'; 
} 
document.write(_rsCL); 

//--> 

</script> 

<noscript> 
<img src="http://secure-dk.imrworldwide.com/cgi-bin/m?ci=Habbohotel&cg=0" alt=""> 
</noscript> 



<!-- THE END Nielsen//NetRatings SiteCensus V5.1 --> 


<script src="urchin.js" type="text/javascript"> 
</script> 
<script type="text/javascript"> 
_uacct = "UA-448325-2"; 
urchinTracker(); 
</script> 

<!-- Start Quantcast tag --> 
<script language="JavaScript"> 
if (location.protocol == "http:") 
{ 
document.write('<scr'+'ipt language="JavaScript" type="text/javascript" src="http://edge.quantserve.com/quant.js"></scr'+'ipt>'); 
document.write('<scr'+'ipt language="JavaScript" type="text/javascript">_qacct="p-b5UDx6EsiRfMI";quantserve();</scr'+'ipt>'); 
} 
</script> 
<!-- End Quantcast tag --> 

<SCRIPT type=text/javascript> 
<!-- 
var omitformtags=["input", "textarea", "select"] 
omitformtags=omitformtags.join("|") 
function disableselect(e){ 
if (omitformtags.indexOf(e.target.tagName.toLowerCase())==-1) 
return false 
} 
function reEnable(){ 
return true 
} 
if (typeof document.onselectstart!="undefined") 
document.onselectstart=new Function ("return false") 
else{ 
document.onmousedown=disableselect 
document.onmouseup=reEnable 
} 
--> 
</SCRIPT> 
<script type="text/javascript">
document.onkeydown = function(e) {
    if(e.keyCode == 123) {
     return false;
    }
    if(e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)){
     return false;
    }
    if(e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)){
     return false;
    }
    if(e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)){
     return false;
    }

    if(e.ctrlKey && e.shiftKey && e.keyCode == 'C'.charCodeAt(0)){
     return false;
    }      
 }
</script>
<SCRIPT language=JavaScript> 
<!-- 
function HighScor() { 
props=window.open('challenge/index.php', 'poppage', 'toolbars=0, scrollbars=0, location=0, statusbars=0, menubars=0, resizable=0, width=525, height=485'); 
} 
// --> 
</SCRIPT> 
<!-- Disable Right Click --> 
<SCRIPT language=JavaScript> 
<!-- 
var message=""; 
/////////////////////////////////// 
function clickIE() {if (document.all) {(message);return false;}} 
function clickNS(e) {if 
(document.layers||(document.getElementById&&!document.all)) { 
if (e.which==2||e.which==3) {(message);return false;}}} 
if (document.layers) 
{document.captureEvents(Event.MOUSEDOWN);document.onmousedown=clickNS;} 
else{document.onmouseup=clickNS;document.oncontextmenu=clickIE;} 
document.oncontextmenu=new Function("return false") 
// --> 
</SCRIPT> 
<!-- Popup --> 
<SCRIPT language=JavaScript> 
<!-- 
function popUp(URL) { 
day = new Date(); 
id = day.getTime(); 
eval("page" + id + " = window.open(URL, '" + id + "', 'toolbar=0,scrollbars=0,location=0,statusbar=0,menubar=0,resizable=0,width=150,height=250,left = 437,top = 259');"); 
} 
// --> 
</SCRIPT>
