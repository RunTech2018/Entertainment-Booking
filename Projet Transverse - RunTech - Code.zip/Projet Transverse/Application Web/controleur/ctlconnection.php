<?php

if (isset($_REQUEST['action'])) {
	$action = $_REQUEST['action'];
}
switch($action)
{
	case 'seconnecter':
	{
		include ("vues/connection/identification.php"); break;
	}

	case 'inscription':
	{
		include("vues/connection/inscription.php"); break;
	}
			
	case 'verifLogin' :
	{

		$login=$_POST['username'];
		$mdp=$_POST['password'];

		if ($login == NULL && $mdp == NULL ) {
			echo 'Veuillez remplir les champs pour entrer sur le site';
			include ("vues/connection/identification.php"); break;
		}
		else{
			$encrypted_txt = md5($mdp);
			require_once 'modele/ModelConnexion.php';
			$user = ModelConnexion::getUser($login, $encrypted_txt);
			$service = $user[11];
			if (is_array($user))
			{
				
				$_SESSION['username']=$login;
				$_SESSION['service']= $service;
				$_SESSION['id']=$user[0];
				
				header('Location: index.php?ctl=accueil&action=home');
				break;
			} 
			else
			{
				header('Location: index.php?ctl=connection&action=seconnecter');break;
			}
		}
		
	}

	
	case 'mdpOublier':
	{
		include ("vues/connection/email.php");
		break;
	}
		
	case 'deconnexion':
	{
		session_unset();	
		session_destroy();
		header('Location: index.php?ctl=connection&action=seconnecter');
		break;
	}
			
	case 'recupemail':
	{
		require_once 'modele/ModelProfil.php';
		$mdp= ModelProfil::getMdp($sendto);
		$destinataire = $_POST['mail'];
// Pour les champs $expediteur / $copie / $destinataire, séparer par une virgule s'il y a plusieurs adresses
		$expediteur = 'aniladrien@sfr.fr';
		$objet = $_POST['Mot de passe oublié'];
		$headers  = 'MIME-Version: 1.0' . "\n"; // Version MIME
		$headers .= 'Content-type: text/html; charset=ISO-8859-1'."\n"; // l'en-tete Content-type pour le format HTML
		$headers .= 'Reply-To: '.$expediteur."\n"; // Mail de reponse
		$headers .= 'From: "Nom_de_expediteur"<'.$expediteur.'>'."\n"; // Expediteur
		$headers .= 'Delivered-to: '.$destinataire."\n"; // Destinataire    
		$message = 'Bonjour !'.'<br>'.' Suite à votre demande, votre mot de passe est '.$mdp.'. Si vous souhaitez le modifier, il faudra contacter la secrétaire ! '.'<br>'.'Bien cordialement,';
		if (mail($destinataire, $objet, $message, $headers)) // Envoi du message
		{
    		echo 'Votre message a bien été envoyé ';
		}
		else // Non envoyé
		{
    	echo "Votre message n'a pas pu être envoyé";
		}
	}
}
?>		