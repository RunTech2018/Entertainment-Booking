<?php
$action = $_REQUEST['action'];
switch($action){
	case 'home':
	{
		include('vues/home.php');
	}
	case 'homeGarage'{
		include('vues/homeGarage.php');
	}
}
?>