<?php
require_once './modele/ModelProfil.php';
//if (isset($action)) {
$action=$_REQUEST['action'];
//}
//else{
//	header('Location: index.php?ctl=connection&action=seconnecter');
//}

switch($action){

	case 'inscription' :
	{

		$login=$_POST['username'];
		$mdp=$_POST['password'];
		$name = $_POST['name'];
		$prenom = $_POST['prenom'];
		$email = $_POST['email'];

		if ($login == NULL && $mdp == NULL && $name== NULL && $prenom == NULL && $email == NULL || $login == NULL || $mdp==NULL || $name == NULL || $prenom == NULL || $email ==NULL) {
			echo '<p>Veuillez remplir les champs pour compléter votre inscription ! </p>';
		}
		else{
			$encrypted_txt = md5($mdp);
		require_once 'modele/ModelConnexion.php';
		$user = ModelProfil::addUser($name, $prenom, $email, $login, $encrypted_txt);
		include("vues/connection/inscription.php");
		break;
		}
		
	}
case 'infoProfil':{
				$profil = ModelProfil::getProfil($_SESSION['id']);
				include("vues/profil/monProfil.php");
				break;
				}
			
case 'modifierProfil':{
		$nom= $_POST['nom'];
		$prenom = $_POST['prenom'];
		$login = $_POST['login'];
		$email = $_POST['email'];
		$mobile = $_POST['mobile'];
		$id = $_SESSION['id'];
		$profil = ModelProfil::getProfil($_SESSION['id']);
		$modifier = ModelProfil::Update($id, $nom, $prenom, $login, $mobile, $email);
		include("vues/profil/monProfil.php");
		break;
	}
case 'modifierPassword':{
	$profil = ModelProfil::getProfil($_SESSION['id']);
				include("vues/profil/password.php");
				break;
}
case 'changePassword':{
		$mdp = $_POST['mdp'];
		$id = $_SESSION['id'];
		$encrypted_txt = md5($mdp);
echo "\n";
		$profil = ModelProfil::getProfil($_SESSION['id']);
		$modifier = ModelProfil::UpdatePassword($id, $encrypted_txt);
		include("vues/profil/password.php");
		break;
}
}
?>
