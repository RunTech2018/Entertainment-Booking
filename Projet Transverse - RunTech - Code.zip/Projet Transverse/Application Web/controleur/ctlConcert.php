<?php
require_once './modele/ModelConcert.php';
$action = $_REQUEST['action'];
switch($action){
case 'infoConcert':{
				//$idp = $_SESSION['id'];
				//$vehicule = ModelCinema::getGenreCinema();
				include("vues/page/consultSpectacle.php");
				break;
				}
case 'listeConcert':{
				$q=$_POST['concert'];
				$r = $_POST['tagconcert'];

				if ($q == NULL) {
					echo 'Veuillez remplir le champ Type de Spectacle pour effectuer votre recherche !';
					include("vues/page/consultSport.php");
					break;
				}
				if ($r == NULL) {
					echo 'Veuillez remplir le champ thème du spectacle pour effectuer votre recherche !';
					include("vues/page/consultSport.php");
					break;
				}
				else{

								$listconcert = ModelConcert::getListeConcert($q, $r);
								include("vues/page/consultListConcert.php");
								break;
					}			
				}
case 'prix':{
		$prix = $_POST['prix'];
		$listconcertprix = ModelConcert::getListeConcertPrix($prix);
		include("vues/page/consultListConcertPrix.php");
		break;
	}
}

?>