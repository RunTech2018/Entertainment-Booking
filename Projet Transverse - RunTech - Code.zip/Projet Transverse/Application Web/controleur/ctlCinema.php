<?php
require_once './modele/ModelCinema.php';
$action = $_REQUEST['action'];
switch($action){
case 'infoCinema':{
				//$idp = $_SESSION['id'];
				//$vehicule = ModelCinema::getGenreCinema();
				include("vues/page/consultCine.php");
				break;
				}
case 'listeCinema':{
				$genrefilm=$_POST['genre'];
				$tagfilm=$_POST['tagfilm'];

				if ($genrefilm == NULL ) {
					echo 'Veuillez remplir le champ définissant le genre de film que vous voulez voir !';
					include("vues/page/consultCine.php");
					break;
				}
				elseif ($tagfilm == NULL) {
					echo 'Veuillez nous indiquer le thème du film que vous souhaitez voir !';
					include("vues/page/consultCine.php");
					break;
				}
				elseif ($genrefilm == NULL && $tagfilm == NULL) {
					echo 'Veuillez remplir les deux champ pour effectuer votre recherche';
					include("vues/page/consultCine.php");
					break;
				}
				else{
					$listvehicule = ModelCinema::getListeCinema($genrefilm, $tagfilm);
					include("vues/page/consultListCine.php");
					break;
				}
		}
}
?>