﻿namespace EBProduction
{
    partial class FormPle
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fichierToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quitterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cinémaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gérerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gérerToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.spectacleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gérerToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.autresTypesDeDivertissementToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gestionDesMuséesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.parcToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gestionDeParcToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.DodgerBlue;
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fichierToolStripMenuItem,
            this.cinémaToolStripMenuItem,
            this.sportToolStripMenuItem,
            this.spectacleToolStripMenuItem,
            this.autresTypesDeDivertissementToolStripMenuItem,
            this.parcToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1358, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fichierToolStripMenuItem
            // 
            this.fichierToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.quitterToolStripMenuItem});
            this.fichierToolStripMenuItem.Name = "fichierToolStripMenuItem";
            this.fichierToolStripMenuItem.Size = new System.Drawing.Size(64, 24);
            this.fichierToolStripMenuItem.Text = "Fichier";
            // 
            // quitterToolStripMenuItem
            // 
            this.quitterToolStripMenuItem.Name = "quitterToolStripMenuItem";
            this.quitterToolStripMenuItem.Size = new System.Drawing.Size(130, 26);
            this.quitterToolStripMenuItem.Text = "Quitter";
            this.quitterToolStripMenuItem.Click += new System.EventHandler(this.quitterToolStripMenuItem_Click);
            // 
            // cinémaToolStripMenuItem
            // 
            this.cinémaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.gérerToolStripMenuItem});
            this.cinémaToolStripMenuItem.Name = "cinémaToolStripMenuItem";
            this.cinémaToolStripMenuItem.Size = new System.Drawing.Size(71, 24);
            this.cinémaToolStripMenuItem.Text = "Cinéma";
            // 
            // gérerToolStripMenuItem
            // 
            this.gérerToolStripMenuItem.Name = "gérerToolStripMenuItem";
            this.gérerToolStripMenuItem.Size = new System.Drawing.Size(199, 26);
            this.gérerToolStripMenuItem.Text = "Gestion des Films";
            this.gérerToolStripMenuItem.Click += new System.EventHandler(this.gérerToolStripMenuItem_Click);
            // 
            // sportToolStripMenuItem
            // 
            this.sportToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.gérerToolStripMenuItem1});
            this.sportToolStripMenuItem.Name = "sportToolStripMenuItem";
            this.sportToolStripMenuItem.Size = new System.Drawing.Size(57, 24);
            this.sportToolStripMenuItem.Text = "Sport";
            // 
            // gérerToolStripMenuItem1
            // 
            this.gérerToolStripMenuItem1.Name = "gérerToolStripMenuItem1";
            this.gérerToolStripMenuItem1.Size = new System.Drawing.Size(238, 26);
            this.gérerToolStripMenuItem1.Text = "Gérer la liste des sports";
            this.gérerToolStripMenuItem1.Click += new System.EventHandler(this.gérerToolStripMenuItem1_Click);
            // 
            // spectacleToolStripMenuItem
            // 
            this.spectacleToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.gérerToolStripMenuItem2});
            this.spectacleToolStripMenuItem.Name = "spectacleToolStripMenuItem";
            this.spectacleToolStripMenuItem.Size = new System.Drawing.Size(85, 24);
            this.spectacleToolStripMenuItem.Text = "Spectacle";
            // 
            // gérerToolStripMenuItem2
            // 
            this.gérerToolStripMenuItem2.Name = "gérerToolStripMenuItem2";
            this.gérerToolStripMenuItem2.Size = new System.Drawing.Size(238, 26);
            this.gérerToolStripMenuItem2.Text = "Gérer";
            this.gérerToolStripMenuItem2.Click += new System.EventHandler(this.gérerToolStripMenuItem2_Click);
            // 
            // autresTypesDeDivertissementToolStripMenuItem
            // 
            this.autresTypesDeDivertissementToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.gestionDesMuséesToolStripMenuItem});
            this.autresTypesDeDivertissementToolStripMenuItem.Name = "autresTypesDeDivertissementToolStripMenuItem";
            this.autresTypesDeDivertissementToolStripMenuItem.Size = new System.Drawing.Size(64, 24);
            this.autresTypesDeDivertissementToolStripMenuItem.Text = "Musée";
            // 
            // gestionDesMuséesToolStripMenuItem
            // 
            this.gestionDesMuséesToolStripMenuItem.Name = "gestionDesMuséesToolStripMenuItem";
            this.gestionDesMuséesToolStripMenuItem.Size = new System.Drawing.Size(214, 26);
            this.gestionDesMuséesToolStripMenuItem.Text = "Gestion des Musées";
            this.gestionDesMuséesToolStripMenuItem.Click += new System.EventHandler(this.gestionDesMuséesToolStripMenuItem_Click);
            // 
            // parcToolStripMenuItem
            // 
            this.parcToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.gestionDeParcToolStripMenuItem});
            this.parcToolStripMenuItem.Name = "parcToolStripMenuItem";
            this.parcToolStripMenuItem.Size = new System.Drawing.Size(48, 24);
            this.parcToolStripMenuItem.Text = "Parc";
            // 
            // gestionDeParcToolStripMenuItem
            // 
            this.gestionDeParcToolStripMenuItem.Name = "gestionDeParcToolStripMenuItem";
            this.gestionDeParcToolStripMenuItem.Size = new System.Drawing.Size(188, 26);
            this.gestionDeParcToolStripMenuItem.Text = "Gestion de parc";
            this.gestionDeParcToolStripMenuItem.Click += new System.EventHandler(this.gestionDeParcToolStripMenuItem_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(1171, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "label1";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = global::EBProduction.Properties.Resources.RunTech_Logo_part2;
            this.pictureBox1.Location = new System.Drawing.Point(491, 127);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(383, 387);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // FormPle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::EBProduction.Properties.Resources.fond_logo;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1358, 619);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "FormPle";
            this.Text = "Entertainment Search Engine Database";
            this.Load += new System.EventHandler(this.FormPle_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fichierToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quitterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cinémaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gérerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gérerToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem spectacleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gérerToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem autresTypesDeDivertissementToolStripMenuItem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripMenuItem gestionDesMuséesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem parcToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gestionDeParcToolStripMenuItem;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

