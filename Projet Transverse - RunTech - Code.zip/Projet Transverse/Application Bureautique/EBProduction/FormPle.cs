﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using EBProduction.cvue.vCinema;

namespace EBProduction
{
    public partial class FormPle : Form
    {
        public static MySqlConnection objcnx;
        public static List<string> libellecategorie = new List<string>();
        public FormPle()
        {
            InitializeComponent();
        }

        private void quitterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void FormPle_Load(object sender, EventArgs e)
        {
            cdata.DbMysql objDb = cdata.DbMysql.getInstance();
            string ctrCnx = "Database=entertainmentbd;Data Source=localhost;User Id=root;Password=";
     
            objcnx = objDb.getConnect(ctrCnx);
            if (objcnx.State == ConnectionState.Open)
            {
                label1.Text = "Connection Ok !";
                label1.ForeColor = Color.Green;
            }
            else
            {
                label1.Text = "Connexion échoué !";
                label1.ForeColor = Color.Red;
                menuStrip1.Items[1].Visible = false;
                menuStrip1.Items[2].Visible = false;
                menuStrip1.Items[3].Visible = false;
                menuStrip1.Items[4].Visible = false;
            }
        }

        private void gérerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            cvue.vCinema.cinema cinema = new cvue.vCinema.cinema();
            cinema.Show();
        }

        private void gestionsDesTagsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            cvue.vCinema.Tag tag = new cvue.vCinema.Tag();
            tag.Show();
        }

        private void gérerToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            cvue.vSport.Sport sport = new cvue.vSport.Sport();
            sport.Show();
        }

        private void catégoriesDeSportsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            cvue.vSport.categorieSport categoriesport = new cvue.vSport.categorieSport();
            categoriesport.Show();
        }

        private void gestionDesMuséesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            cvue.vMusee.Musee musee = new cvue.vMusee.Musee();
            musee.Show();
        }

        private void catégorieDeSpectacleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            cvue.vConcert.categoriesconcert style = new cvue.vConcert.categoriesconcert();
            style.Show();

        }

        private void typeDeMuséesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            cvue.vMusee.TagMusee tagmusee = new cvue.vMusee.TagMusee();
            tagmusee.Show();
        }

        private void gérerToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            cvue.vConcert.Spectacle spectacle = new cvue.vConcert.Spectacle();
            spectacle.Show();
        }

        private void gestionDeParcToolStripMenuItem_Click(object sender, EventArgs e)
        {
            cvue.vParc.Parc parc = new cvue.vParc.Parc();
            parc.Show();
        }
    }
}
