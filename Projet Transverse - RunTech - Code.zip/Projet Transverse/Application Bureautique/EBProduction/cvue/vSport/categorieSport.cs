﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace EBProduction.cvue.vSport
{
    public partial class categorieSport : Form
    {
        public categorieSport()
        {
            InitializeComponent();
        }

        private void chargementSportTag()
        {
            try
            {
                string sql = "SELECT * FROM categoriesport";
                MySqlCommand cmdSql = FormPle.objcnx.CreateCommand();
                cmdSql.CommandText = sql;
                MySqlDataReader resultat = cmdSql.ExecuteReader();
                while (resultat.Read())
                {
                    string id = resultat.GetValue(0).ToString();
                    string nom = resultat.GetValue(1).ToString();
                    dataGridView1.Rows.Add(id, nom);
                }
                resultat.Close();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message.ToString());
            }
        }
        private void categorieSport_Load(object sender, EventArgs e)
        {
            chargementSportTag();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                int num = int.Parse(label1.Text);
                cdata.SportDb.delete(num);
                MessageBox.Show("Suppression ajouté");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());

            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.SelectedCells.Count > 0)
            {
                int indice = dataGridView1.CurrentCell.RowIndex;
                string id = dataGridView1.Rows[indice].Cells[0].Value.ToString();
                string nom = dataGridView1.Rows[indice].Cells[1].Value.ToString();
                label1.Text = id;
                textBox1.Text = nom;

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string tag = textBox1.Text;
                cdata.SportDb.ajouterTag(tag);
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message.ToString());
            }
        }
    }
}
