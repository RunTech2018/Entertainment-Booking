﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace EBProduction.cvue.vSport
{
    public partial class Sport : Form
    {
        public Sport()
        {
            InitializeComponent();
        }
        //private void Fillcombo()
        //{
        //    string sql = "SELECT * FROM categoriesport";
        //    MySqlCommand cmdSql = FormPle.objcnx.CreateCommand();
        //    cmdSql.CommandText = sql;
        //    MySqlDataReader resultat = cmdSql.ExecuteReader();
        //    while (resultat.Read())
        //    {
        //        string libelle = resultat.GetValue(1).ToString();
        //        comboBox2.Items.Add(libelle);
        //    }
        //    resultat.Close();
        //}

        private void Sport_Load(object sender, EventArgs e)
        {
           // Fillcombo();
            chargementSport();
        }
        private void chargementSport()
        {
            try
            {
                string sql = "SELECT * FROM sport";
                MySqlCommand cmdSql = FormPle.objcnx.CreateCommand();
                cmdSql.CommandText = sql;
                MySqlDataReader resultat = cmdSql.ExecuteReader();
                while (resultat.Read())
                {
                    string id = resultat.GetValue(0).ToString();
                    string nom = resultat.GetValue(1).ToString();
                    string type_sport = resultat.GetValue(2).ToString();
                    string club = resultat.GetValue(3).ToString();
                    string adresse = resultat.GetValue(4).ToString();
                    string note = resultat.GetValue(5).ToString();
                    dataGridView1.Rows.Add(id, nom, type_sport, club, adresse, note);
                }
                resultat.Close();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message.ToString());
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string categoriesport = comboBox2.Text;
                string libellesport = textBox1.Text;
                string club = textBox2.Text;
                string adresse = textBox3.Text;
                int note_club = int.Parse(textBox4.Text);
                cdata.SportDb.ajouterSport(libellesport, categoriesport, club, adresse, note_club);
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message.ToString());
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                int num = int.Parse(label1.Text);
                string categoriesport = comboBox2.Text;
                string libellesport = textBox1.Text;
                string club = textBox2.Text;
                string adresse = textBox3.Text;
                int note_club = int.Parse(textBox4.Text);
                cdata.SportDb.changersport(libellesport, categoriesport, club, adresse, note_club, num);
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message.ToString());
            }
            
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.SelectedCells.Count > 0)
            {
                int indice = dataGridView1.CurrentCell.RowIndex;
                string id = dataGridView1.Rows[indice].Cells[0].Value.ToString();
                string nom = dataGridView1.Rows[indice].Cells[1].Value.ToString();
                string categoriesport = dataGridView1.Rows[indice].Cells[2].Value.ToString();
                string club = dataGridView1.Rows[indice].Cells[3].Value.ToString();
                string adresse = dataGridView1.Rows[indice].Cells[4].Value.ToString();
                string note = dataGridView1.Rows[indice].Cells[5].Value.ToString();

                label1.Text = id;
                textBox1.Text = nom;
                textBox2.Text = club;
                textBox3.Text = adresse;
                textBox4.Text = note;
                comboBox2.Text = categoriesport;

            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                int num = int.Parse(label1.Text);
                cdata.CinemaDb.delete(num);
                MessageBox.Show("Suppression ajouté");
                chargementSport();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());

            }
        }
    }
}
