﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace EBProduction.cvue.vCinema
{
    public partial class cinema : Form
    {
        public cinema()
        {
            InitializeComponent();
        }
        //private void Fillcombo()
        //{
        //    string sql = "SELECT * FROM categoriefilm";
        //    MySqlCommand cmdSql = FormPle.objcnx.CreateCommand();
        //    cmdSql.CommandText = sql;
        //    MySqlDataReader resultat = cmdSql.ExecuteReader();
        //    while (resultat.Read())
        //    {
        //        string libelle = resultat.GetValue(1).ToString();
        //        comboBox2.Items.Add(libelle);
        //    }
        //    resultat.Close();
        //}
        private void chargementCinema()
        {
            try
            {
                string sql = "SELECT * FROM cinema";
                MySqlCommand cmdSql = FormPle.objcnx.CreateCommand();
                cmdSql.CommandText = sql;
                MySqlDataReader resultat = cmdSql.ExecuteReader();
                while (resultat.Read())
                {
                    string id = resultat.GetValue(0).ToString();
                    string nom = resultat.GetValue(1).ToString();
                    string realisation = resultat.GetValue(2).ToString();
                    string  date= resultat.GetValue(3).ToString();
                    string resume = resultat.GetValue(4).ToString();
                    string type_salle = resultat.GetValue(5).ToString();
                    string type_film = resultat.GetValue(6).ToString();
                    string  categoriefilm = resultat.GetValue(7).ToString();
                    int notefilm = int.Parse(resultat.GetValue(8).ToString());
                    dataGridView1.Rows.Add(id, nom, realisation, date, resume, type_salle, type_film, categoriefilm, notefilm);
                }
                resultat.Close();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message.ToString());
            }
        }
        private void cinema_Load(object sender, EventArgs e)
        {
            string categorie = comboBox2.Text;
           // Fillcombo();
            chargementCinema();

        }
        public void chargerCombo()
        {
            int taille = FormPle.libellecategorie.Count;
            for (int i = 0; i < taille; i++)
            {
                //comboBox2.Items.Add(FormPle.libellecategorie[i].getLibelle());
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string nom = textBox1.Text;
                string realisateur = textBox3.Text;
                string date = dateTimePicker1.Text;
                string resume = textBox2.Text;
                string type_salle = textBox4.Text;
                string type_film = textBox5.Text;
                string categoriefilm = comboBox2.Text;
                int note = int.Parse(textBox6.Text);
                cdata.CinemaDb.ajouterFilm(nom, realisateur, date, resume, type_salle, type_film, categoriefilm, note);

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                int id = int.Parse(label3.Text);
                string nom = textBox1.Text;
                string realisateur = textBox3.Text;
                string date = dateTimePicker1.Text;
                string resume = textBox2.Text;
                string type_salle = textBox4.Text;
                string type_film = textBox5.Text;
                string categoriefilm = comboBox2.Text;
                int note = int.Parse(textBox6.Text);
                cdata.CinemaDb.changerfilm(nom, realisateur, date, resume, type_salle, type_film, categoriefilm, note, id);
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.SelectedCells.Count > 0)
            {
                int indice = dataGridView1.CurrentCell.RowIndex;
                string id = dataGridView1.Rows[indice].Cells[0].Value.ToString();
                string nom = dataGridView1.Rows[indice].Cells[1].Value.ToString();
                string realisateur = dataGridView1.Rows[indice].Cells[2].Value.ToString();
                string date = dataGridView1.Rows[indice].Cells[3].Value.ToString();
                string resume = dataGridView1.Rows[indice].Cells[4].Value.ToString();
                string type_salle = dataGridView1.Rows[indice].Cells[5].Value.ToString();
                string type_film = dataGridView1.Rows[indice].Cells[6].Value.ToString();
                string categoriefilm= dataGridView1.Rows[indice].Cells[7].Value.ToString();
                label3.Text = id;
                textBox1.Text = nom;
                textBox3.Text = realisateur;
                dateTimePicker1.Text = date;
                textBox2.Text = resume;
                textBox4.Text = type_salle;
                textBox5.Text = type_film;
                comboBox2.Text = categoriefilm;

            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                int num = int.Parse(label3.Text);
                cdata.CinemaDb.delete(num);
                MessageBox.Show("Suppression ajouté");
                chargementCinema();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());

            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }
    }
}
