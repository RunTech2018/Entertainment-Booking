﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace EBProduction.cvue.vMusee
{
    public partial class Musee : Form
    {
        public Musee()
        {
            InitializeComponent();
        }
        //private void Fillcombo()
        //{
        //    string sql = "SELECT * FROM categoriemusee";
        //    MySqlCommand cmdSql = FormPle.objcnx.CreateCommand();
        //    cmdSql.CommandText = sql;
        //    MySqlDataReader resultat = cmdSql.ExecuteReader();
        //    while (resultat.Read())
        //    {
        //        string libelle = resultat.GetValue(1).ToString();
        //        comboBox2.Items.Add(libelle);
        //    }
        //    resultat.Close();
        //}
        private void chargementCinema()
        {
            try
            {
                string sql = "SELECT * FROM musee";
                MySqlCommand cmdSql = FormPle.objcnx.CreateCommand();
                cmdSql.CommandText = sql;
                MySqlDataReader resultat = cmdSql.ExecuteReader();
                while (resultat.Read())
                {
                    string id = resultat.GetValue(0).ToString();
                    string nom = resultat.GetValue(1).ToString();
                    string adresse = resultat.GetValue(2).ToString();
                    string description = resultat.GetValue(3).ToString();
                    string resume = resultat.GetValue(4).ToString();
                    int prix = int.Parse(resultat.GetValue(5).ToString());
                    dataGridView1.Rows.Add(id, nom, adresse, description, resume, prix);
                }
                resultat.Close();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message.ToString());
            }
        }
        private void Musee_Load(object sender, EventArgs e)
        {
            //Fillcombo();
            chargementCinema();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string nom = textBox1.Text;
                string adresse = textBox3.Text;
                string resume = textBox2.Text;
                string categoriemusee = comboBox2.Text;
                int prix = int.Parse(textBox7.Text);
                cdata.MuseeDb.ajouterMusee(nom, adresse, resume, categoriemusee, prix);

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.SelectedCells.Count > 0)
            {
                int indice = dataGridView1.CurrentCell.RowIndex;
                string id = dataGridView1.Rows[indice].Cells[0].Value.ToString();
                string nom = dataGridView1.Rows[indice].Cells[1].Value.ToString();
                string adresse = dataGridView1.Rows[indice].Cells[2].Value.ToString();
                string resume = dataGridView1.Rows[indice].Cells[3].Value.ToString();
                string type = dataGridView1.Rows[indice].Cells[4].Value.ToString();
                string prix = dataGridView1.Rows[indice].Cells[5].Value.ToString();
                label3.Text = id;
                textBox1.Text = nom;
                textBox3.Text = adresse;
                textBox2.Text = resume;
                comboBox2.Text = type;
                textBox7.Text = prix;

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                int id = int.Parse(label3.Text);
                string nom = textBox1.Text;
                string adresse = textBox3.Text;
                string resume = textBox2.Text;
                string categoriemusee = comboBox2.Text;
                int prix = int.Parse(textBox7.Text);
                cdata.MuseeDb.changermusee(nom, adresse, resume, categoriemusee, prix, id);

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                int num = int.Parse(label3.Text);
                cdata.MuseeDb.delete(num);
                MessageBox.Show("Suppression ajouté");
                chargementCinema();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());

            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
