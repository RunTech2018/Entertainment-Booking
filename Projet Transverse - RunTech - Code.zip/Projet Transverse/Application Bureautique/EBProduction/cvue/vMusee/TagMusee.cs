﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace EBProduction.cvue.vMusee
{
    public partial class TagMusee : Form
    {
        public TagMusee()
        {
            InitializeComponent();
        }
        private void chargementSportTag()
        {
            try
            {
                string sql = "SELECT * FROM categoriemusee";
                MySqlCommand cmdSql = FormPle.objcnx.CreateCommand();
                cmdSql.CommandText = sql;
                MySqlDataReader resultat = cmdSql.ExecuteReader();
                while (resultat.Read())
                {
                    string id = resultat.GetValue(0).ToString();
                    string nom = resultat.GetValue(1).ToString();
                    dataGridView1.Rows.Add(id, nom);
                }
                resultat.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string tag = textBox1.Text;
                cdata.MuseeDb.ajouterTag(tag);
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                int num = int.Parse(label1.Text);
                cdata.MuseeDb.delete(num);
                MessageBox.Show("Suppression ajouté");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());

            }
        }

        private void TagMusee_Load(object sender, EventArgs e)
        {
            chargementSportTag();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
