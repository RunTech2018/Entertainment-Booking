﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace EBProduction.cvue.vConcert
{
    public partial class Spectacle : Form
    {
        public Spectacle()
        {
            InitializeComponent();
        }
        //private void Fillcombo()
        //{
        //    string sql = "SELECT * FROM categorieconcert";
        //    MySqlCommand cmdSql = FormPle.objcnx.CreateCommand();
        //    cmdSql.CommandText = sql;
        //    MySqlDataReader resultat = cmdSql.ExecuteReader();
        //    while (resultat.Read())
        //    {
        //        string libelle = resultat.GetValue(1).ToString();
        //        comboBox2.Items.Add(libelle);
        //    }
        //    resultat.Close();
        //}

        private void updatespectacle()
        {
            var today = DateTime.Now;
            var yesterday = today.AddDays(-1).ToString();

            label10.Text = yesterday;
            string date = label10.Text;
            date = yesterday;

            cdata.ConcertDb.deleteday(date);

        }
        private void chargementConcert()
        {
            try
            {
                string sql = "SELECT * FROM concert";
                MySqlCommand cmdSql = FormPle.objcnx.CreateCommand();
                cmdSql.CommandText = sql;
                MySqlDataReader resultat = cmdSql.ExecuteReader();
                while (resultat.Read())
                {
                    string id = resultat.GetValue(0).ToString();
                    string nom = resultat.GetValue(1).ToString();
                    string groupe = resultat.GetValue(2).ToString();
                    string resume = resultat.GetValue(4).ToString();
                    string  date = resultat.GetValue(3).ToString();
                    string adresse = resultat.GetValue(5).ToString();
                    string type_spectacle = resultat.GetValue(6).ToString();
                    string categoriespectacle = resultat.GetValue(7).ToString();
                    int notespectacle = int.Parse(resultat.GetValue(8).ToString());
                    int prix = int.Parse(resultat.GetValue(9).ToString());
                    dataGridView1.Rows.Add(id, nom, groupe, date, resume, adresse, type_spectacle, categoriespectacle, notespectacle, prix);
                }
                resultat.Close();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message.ToString());
            }
        }
        private void Spectacle_Load(object sender, EventArgs e)
        {
            //Fillcombo();
            chargementConcert();
            //updatespectacle();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string nom = textBox1.Text;
                string  groupe = textBox3.Text;
                string date = dateTimePicker1.Text;
                string resume = textBox2.Text;
                string adresse = textBox4.Text;
                string type_spectacle = textBox5.Text;
                string categoriespectacle = comboBox2.Text;
                int notespectacle = int.Parse(textBox6.Text);
                int prix = int.Parse(textBox7.Text);
                cdata.ConcertDb.ajouterSpectacle(nom, groupe, resume, date, adresse, type_spectacle, categoriespectacle, notespectacle, prix);
                chargementConcert();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                int id = int.Parse(label3.Text);
                string nom = textBox1.Text;
                string groupe = textBox3.Text;
                string date = dateTimePicker1.Text;
                string resume = textBox2.Text;
                string adresse = textBox4.Text;
                string type_spectacle = textBox5.Text;
                string categoriespectacle = comboBox2.Text;
                int notespectacle = int.Parse(textBox6.Text);
                int prix = int.Parse(textBox7.Text);
                cdata.ConcertDb.changerspectacle(nom, groupe, resume, date, adresse, type_spectacle, categoriespectacle, notespectacle, prix, id);
                chargementConcert();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message.ToString());
            }
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                int num = int.Parse(label3.Text);
                cdata.ConcertDb.delete(num);
                MessageBox.Show("Suppression ajouté");
                chargementConcert();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());

            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.SelectedCells.Count > 0)
            {
                int indice = dataGridView1.CurrentCell.RowIndex;
                string id = dataGridView1.Rows[indice].Cells[0].Value.ToString();
                string nom = dataGridView1.Rows[indice].Cells[1].Value.ToString();
                string realisateur = dataGridView1.Rows[indice].Cells[2].Value.ToString();
                string date = dataGridView1.Rows[indice].Cells[3].Value.ToString();
                string resume = dataGridView1.Rows[indice].Cells[4].Value.ToString();
                string type_salle = dataGridView1.Rows[indice].Cells[5].Value.ToString();
                string type_film = dataGridView1.Rows[indice].Cells[6].Value.ToString();
                string categoriefilm = dataGridView1.Rows[indice].Cells[7].Value.ToString();
                string note = dataGridView1.Rows[indice].Cells[8].Value.ToString();
                string prix = dataGridView1.Rows[indice].Cells[9].Value.ToString();
                label3.Text = id;
                textBox1.Text = nom;
                textBox3.Text = realisateur;
                dateTimePicker1.Text = date;
                textBox2.Text = resume;
                textBox4.Text = type_salle;
                textBox5.Text = type_film;
                comboBox2.Text = categoriefilm;
                textBox6.Text = note;
                textBox7.Text = prix;

            }

        }
    }
}
