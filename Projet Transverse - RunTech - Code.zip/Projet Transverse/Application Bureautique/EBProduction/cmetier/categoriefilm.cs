﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EBProduction.cmetier
{
    class categoriefilm
    {
        private int id;
        private string libelle;

        public categoriefilm(int unId, string unLibelle)
        {
            id = unId;
            libelle = unLibelle;
        }
        public string getLibelle()
        {
            return libelle;
        }
        public void setLibelle(string unLibelle)
        {
            libelle = unLibelle;
        }
    }
}
