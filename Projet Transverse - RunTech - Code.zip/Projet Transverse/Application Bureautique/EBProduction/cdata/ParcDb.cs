﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace EBProduction.cdata
{
    class ParcDb
    {
        public static void ajouterParc(string nom, string adresse, string resume, string type, int prix)
        {
            try
            {
                string sql = "INSERT INTO parc (nom, adresse, description, categorie, prix) VALUES ('" + nom + "','" + adresse + "','" + resume + "','" + type + "','"+ prix + "')";
                MessageBox.Show(sql);
                MySqlCommand cmdSql = FormPle.objcnx.CreateCommand();
                cmdSql.CommandText = sql;
                cmdSql.ExecuteNonQuery();
                MessageBox.Show("Enregistrement effectué");
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message.ToString());
            }
        }

        public static void ajouterTag(string tag)
        {
            try
            {
                string sql = "INSERT INTO categoriesmusee (libelle_categoriemusee) VALUES ('" + tag + "')";
                MessageBox.Show(sql);
                MySqlCommand cmdSql = FormPle.objcnx.CreateCommand();
                cmdSql.CommandText = sql;
                cmdSql.ExecuteNonQuery();
                MessageBox.Show("Enregistrement effectué");
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message.ToString());
            }
        }
        public static void changerparc(string nom, string adresse, string resume, string type, int prix, int num)
        {
            try
            {
                string sql = "UPDATE parc SET nom='" + nom + "', adresse='" + adresse + "', description='" + resume + "', categorie='" + type + "', prix="+ prix +" WHERE id =" + num;
                MessageBox.Show(sql);
                MySqlCommand cmdSql = FormPle.objcnx.CreateCommand();
                cmdSql.CommandText = sql;
                cmdSql.ExecuteNonQuery();
                MessageBox.Show("Mise à Jour Effectué");
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message.ToString());
            }

        }
        public static void delete(int num)
        {
            try
            {
                string sql = "DELETE from musee WHERE id=" + num;
                MySqlCommand supprimer = FormPle.objcnx.CreateCommand();
                supprimer.CommandText = sql;
                supprimer.ExecuteNonQuery();
                MessageBox.Show("Suprression effectuée");
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message.ToString());
            }

        }
    }
}
