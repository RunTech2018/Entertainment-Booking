﻿using System;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace EBProduction.cdata
{
    class DbMysql
    {
        private static DbMysql instanceMysql;
        private MySqlConnection objconnect;
        //le constructeur
        private DbMysql() { }
        //création de l'objet s'il n'existe pas
        public static DbMysql getInstance()
        {
            if (instanceMysql == null)
            {
                instanceMysql = new DbMysql();
            }
            return instanceMysql;
        }
        public MySqlConnection getCnx()
        {
            return objconnect;
        }
        public MySqlConnection getConnect(string conStr)
        {
            try
            {
                objconnect = new MySqlConnection(conStr);
                objconnect.Open();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message.ToString());
            }
            return objconnect;
        }
    }
}
