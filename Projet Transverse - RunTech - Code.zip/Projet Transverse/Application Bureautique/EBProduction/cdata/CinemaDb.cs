﻿using System;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace EBProduction.cdata
{
    class CinemaDb
    {
        public static void ajouterFilm(string nom, string realisation, string date, string resume, string type_salle, string type_film, string categoriefilm, int note)
        {
            try
            {
                string sql = "INSERT INTO cinema (nom, realisateur, date, resume, type_salle, type_film, categoriefilm, notefilm) VALUES ('" + nom + "','" + realisation + "','" + date + "','" + resume + "','" + type_salle+ "','" + type_film + "','" + categoriefilm +"','"+ note + "')";
                MessageBox.Show(sql);
                MySqlCommand cmdSql = FormPle.objcnx.CreateCommand();
                cmdSql.CommandText = sql;
                cmdSql.ExecuteNonQuery();
                MessageBox.Show("Enregistrement effectué");
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message.ToString());
            }
        }

        public static void ajouterTag(string tag)
        {
            try
            {
                string sql = "INSERT INTO categoriefilm (Libelle_categorie) VALUES ('" + tag + "')";
                MessageBox.Show(sql);
                MySqlCommand cmdSql = FormPle.objcnx.CreateCommand();
                cmdSql.CommandText = sql;
                cmdSql.ExecuteNonQuery();
                MessageBox.Show("Enregistrement effectué");
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message.ToString());
            }
        }

        public static void changerfilm(string nom, string realisation, string date, string resume, string type_salle, string type_film, string categoriefilm, int note, int num)
        {
            try
            {
                string sql = "UPDATE cinema SET nom='" + nom + "', realisateur='" + realisation + "',date='" + date + "', resume='" + resume + "', type_salle='" + type_salle + "',type_film='" + type_film + "', categoriefilm='" + categoriefilm + "', notefilm=" + note + " WHERE id =" + num;
                MessageBox.Show(sql);
                MySqlCommand cmdSql = FormPle.objcnx.CreateCommand();
                cmdSql.CommandText = sql;
                cmdSql.ExecuteNonQuery();
                MessageBox.Show("Mise à Jour Effectué");
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message.ToString());
            }
            
        }

        public static void changertag(string tag, int num)
        {
            try
            {
                string sql = "UPDATE categoriefilm SET Libelle_categorie='" + tag + "' WHERE id =" + num;
                MessageBox.Show(sql);
                MySqlCommand cmdSql = FormPle.objcnx.CreateCommand();
                cmdSql.CommandText = sql;
                cmdSql.ExecuteNonQuery();
                MessageBox.Show("Mise à Jour Effectué");
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message.ToString());
            }

        }

        public static void delete(int num)
        {
            try
            {
                string sql = "DELETE from cinema WHERE id=" + num;
                MySqlCommand supprimer = FormPle.objcnx.CreateCommand();
                supprimer.CommandText = sql;
                supprimer.ExecuteNonQuery();
                MessageBox.Show("Suprression effectuée");
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message.ToString());
            }

        }

        public static void deletetag(int num)
        {
            try
            {
                string sql = "DELETE from categoriefilm WHERE id=" + num;
                MySqlCommand supprimer = FormPle.objcnx.CreateCommand();
                supprimer.CommandText = sql;
                supprimer.ExecuteNonQuery();
                MessageBox.Show("Suprression effectuée");
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message.ToString());
            }

        }
    }
}
