﻿using System;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace EBProduction.cdata
{
    class SportDb
    {
        public static void ajouterSport(string libelle, string categorie, string club, string adresse, int note_club)
        {
            try
            {
                string sql = "INSERT INTO sport (libelle_sport, type_sport, club, adresse, note_club) VALUES ('" + libelle + "','" + categorie + "','"+club +"','"+ adresse+"','"+ note_club +"')";
                MessageBox.Show(sql);
                MySqlCommand cmdSql = FormPle.objcnx.CreateCommand();
                cmdSql.CommandText = sql;
                cmdSql.ExecuteNonQuery();
                MessageBox.Show("Enregistrement effectué");
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message.ToString());
            }
        }

        public static void ajouterTag(string tag)
        {
            try
            {
                string sql = "INSERT INTO categoriesport (libelle_categoriesport) VALUES ('" + tag + "')";
                MessageBox.Show(sql);
                MySqlCommand cmdSql = FormPle.objcnx.CreateCommand();
                cmdSql.CommandText = sql;
                cmdSql.ExecuteNonQuery();
                MessageBox.Show("Enregistrement effectué");
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message.ToString());
            }
        }
        public static void changersport(string nom, string typesport, string club, string adresse, int note_club, int num)
        {
            try
            {
                string sql = "UPDATE sport SET libelle_sport='" + nom + "', type_sport='" + typesport + "', club='"+ club +"', adresse='"+adresse + "', note_club="+note_club+" WHERE id_sport =" + num;
                MessageBox.Show(sql);
                MySqlCommand cmdSql = FormPle.objcnx.CreateCommand();
                cmdSql.CommandText = sql;
                cmdSql.ExecuteNonQuery();
                MessageBox.Show("Mise à Jour Effectué");
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message.ToString());
            }

        }
        public static void delete(int num)
        {
            try
            {
                string sql = "DELETE from sport WHERE id_sport=" + num;
                MySqlCommand supprimer = FormPle.objcnx.CreateCommand();
                supprimer.CommandText = sql;
                supprimer.ExecuteNonQuery();
                MessageBox.Show("Suprression effectuée");
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message.ToString());
            }

        }

        public static void deletetag(int num)
        {
            try
            {
                string sql = "DELETE from categoriesport WHERE id_categoriesport=" + num;
                MySqlCommand supprimer = FormPle.objcnx.CreateCommand();
                supprimer.CommandText = sql;
                supprimer.ExecuteNonQuery();
                MessageBox.Show("Suprression effectuée");
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message.ToString());
            }

        }
    }
}
