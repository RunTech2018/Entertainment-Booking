﻿using System;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace EBProduction.cdata
{
    class MuseeDb
    {
        public static void ajouterMusee(string nom, string adresse, string resume, string type, int prix )
        {
            try
            {
                string sql = "INSERT INTO musee (nom, adresse, description, type_musee, prix) VALUES ('" + nom + "','" + adresse+ "','" + resume + "','" + type + "','"+prix+"')";
                MessageBox.Show(sql);
                MySqlCommand cmdSql = FormPle.objcnx.CreateCommand();
                cmdSql.CommandText = sql;
                cmdSql.ExecuteNonQuery();
                MessageBox.Show("Enregistrement effectué");
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message.ToString());
            }
        }

        public static void ajouterTag(string tag)
        {
            try
            {
                string sql = "INSERT INTO categoriesmusee (libelle_categoriemusee) VALUES ('" + tag + "')";
                MessageBox.Show(sql);
                MySqlCommand cmdSql = FormPle.objcnx.CreateCommand();
                cmdSql.CommandText = sql;
                cmdSql.ExecuteNonQuery();
                MessageBox.Show("Enregistrement effectué");
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message.ToString());
            }
        }
        public static void changermusee(string nom, string adresse, string resume, string type, int prix, int num)
        {
            try
            {
                string sql = "UPDATE musee SET nom='" + nom + "', adresse='" + adresse + "', description='"+ resume + "', type_musee='"+type +"', prix=" + prix + " WHERE id_musee =" + num;
                MessageBox.Show(sql);
                MySqlCommand cmdSql = FormPle.objcnx.CreateCommand();
                cmdSql.CommandText = sql;
                cmdSql.ExecuteNonQuery();
                MessageBox.Show("Mise à Jour Effectué");
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message.ToString());
            }

        }
        public static void delete(int num)
        {
            try
            {
                string sql = "DELETE from musee WHERE id_musee=" + num;
                MySqlCommand supprimer = FormPle.objcnx.CreateCommand();
                supprimer.CommandText = sql;
                supprimer.ExecuteNonQuery();
                MessageBox.Show("Suprression effectuée");
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message.ToString());
            }

        }

        public static void deletetag(int num)
        {
            try
            {
                string sql = "DELETE from categoriemusee WHERE id=" + num;
                MySqlCommand supprimer = FormPle.objcnx.CreateCommand();
                supprimer.CommandText = sql;
                supprimer.ExecuteNonQuery();
                MessageBox.Show("Suprression effectuée");
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message.ToString());
            }

        }
    }
}
