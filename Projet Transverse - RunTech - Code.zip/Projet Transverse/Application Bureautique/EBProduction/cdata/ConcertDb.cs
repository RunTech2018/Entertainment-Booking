﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace EBProduction.cdata
{
    class ConcertDb
    {
        public static void ajouterSpectacle(string nom, string groupe,  string resume, string date, string adresse, string type_spectacle, string categoriespectacle, int note, int prix)
        {
            try
            {
                string sql = "INSERT INTO concert (nom, auteur, description, date_concert, adresse, type_spectacle, style, note, prix) VALUES ('" + nom + "','" + groupe + "','" + resume + "','" + date + "','" + adresse + "','" + type_spectacle + "','" + categoriespectacle + "','" + note + "','"+prix + "')";
                MessageBox.Show(sql);
                MySqlCommand cmdSql = FormPle.objcnx.CreateCommand();
                cmdSql.CommandText = sql;
                cmdSql.ExecuteNonQuery();
                MessageBox.Show("Enregistrement effectué");
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message.ToString());
            }
        }

        public static void changerspectacle(string nom, string groupe, string resume, string date, string adresse, string type_spectacle, string categoriespectacle, int note, int prix, int num)
        {
            try
            {
                string sql = "UPDATE concert SET nom='" + nom + "', auteur='" + groupe + "',description ='" + resume + "', date_concert='" + date + "', adresse='" + adresse + "',type_spectacle='" + type_spectacle + "', style='" + categoriespectacle + "', note=" + note + ", prix="+ prix+ " WHERE id =" + num;
                MessageBox.Show(sql);
                MySqlCommand cmdSql = FormPle.objcnx.CreateCommand();
                cmdSql.CommandText = sql;
                cmdSql.ExecuteNonQuery();
                MessageBox.Show("Mise à Jour Effectué");
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message.ToString());
            }

        }

        public static void delete(int num)
        {
            try
            {
                string sql = "DELETE from concert WHERE id=" + num;
                MySqlCommand supprimer = FormPle.objcnx.CreateCommand();
                supprimer.CommandText = sql;
                supprimer.ExecuteNonQuery();
                MessageBox.Show("Suprression effectuée");
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message.ToString());
            }

        }

        public static void deleteday(string day)
        {
            try
            {
                string sql = "DELETE from concert WHERE date_concert= '" + day +"'";
                MySqlCommand supprimer = FormPle.objcnx.CreateCommand();
                supprimer.CommandText = sql;
                supprimer.ExecuteNonQuery();
                MessageBox.Show("Suprression effectuée");
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message.ToString());
            }

        }

        public static void ajouterTag(string tag)
        {
            try
            {
                string sql = "INSERT INTO categorieconcert (libelle_categorieconcert) VALUES ('" + tag + "')";
                MessageBox.Show(sql);
                MySqlCommand cmdSql = FormPle.objcnx.CreateCommand();
                cmdSql.CommandText = sql;
                cmdSql.ExecuteNonQuery();
                MessageBox.Show("Enregistrement effectué");
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message.ToString());
            }
        }

        public static void deletetag(int num)
        {
            try
            {
                string sql = "DELETE from categorieconcert WHERE id_categorieconcert=" + num;
                MySqlCommand supprimer = FormPle.objcnx.CreateCommand();
                supprimer.CommandText = sql;
                supprimer.ExecuteNonQuery();
                MessageBox.Show("Suprression effectuée");
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message.ToString());
            }

        }
    }
}
