﻿using System;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace EBProduction.cdata
{
    class CategorieFilmDb
    {
        public static List<cmetier.categoriefilm> getLesCategories()
        {
            List<cmetier.categoriefilm> lescategories = new List<cmetier.categoriefilm>();
            try
            {
                string sql = "SELECT * FROM categoriefilm";
                MySqlCommand cmdSql = FormPle.objcnx.CreateCommand();
                cmdSql.CommandText = sql;
                MySqlDataReader resultat = cmdSql.ExecuteReader();
                while (resultat.Read())
                {
                    int id = int.Parse(resultat.GetValue(0).ToString());
                    string libelle = resultat.GetValue(1).ToString();
                    cmetier.categoriefilm objs = new cmetier.categoriefilm(id, libelle);
                    lescategories.Add(objs);
                }
                resultat.Close();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message.ToString());
            }
            return lescategories;
        }
    }
}
